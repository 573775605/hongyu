<?php

namespace App\Exceptions;

use Exception;

class Base extends Exception
{

}
