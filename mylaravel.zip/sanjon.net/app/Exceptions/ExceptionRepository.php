<?php

namespace App\Exceptions;

class ExceptionRepository extends Base
{

}
