<?php

namespace App\Repositories;

use App\Models\Manager as ManagerModel;

class ManagerList extends BaseList
{
    public static $model = ManagerModel::class;
}
