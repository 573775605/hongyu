<?php

namespace App\Repositories;

use App\Models\UserCoupon as UserCouponModel;

class UserCouponList extends BaseList
{
    public static $model = UserCouponModel::class;

}