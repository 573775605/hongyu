<?php

namespace App\Repositories;

use App\Models\UserTender as UserTenderModel;

class UserTenderList extends BaseList
{
    public static $model = UserTenderModel::class;
}
