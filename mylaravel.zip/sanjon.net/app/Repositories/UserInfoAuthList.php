<?php

namespace App\Repositories;

use App\Models\UserInfoAuth as UserInfoAuthModel;

class UserInfoAuthList extends BaseList
{
    public static $model = UserInfoAuthModel::class;
}
