<?php

namespace App\Repositories;

use App\Models\Coupon as CouponModel;

class CouponList extends BaseList
{
    public static $model = CouponModel::class;

}
