<?php

namespace App\Repositories;

use App\Models\UserHotboomEvaluateLog as UserHotboomEvaluateLogModel;

class UserHotboomEvaluateLogList extends BaseList
{
    public static $model = UserHotboomEvaluateLogModel::class;
}
