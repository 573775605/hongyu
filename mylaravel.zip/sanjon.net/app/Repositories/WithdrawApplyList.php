<?php

namespace App\Repositories;

use App\Models\WithdrawApply as WithdrawApplyModel;

class WithdrawApplyList extends BaseList
{
    public static $model = WithdrawApplyModel::class;
}
