<?php

namespace App\Repositories;

use App\Models\Article as ArticleModel;

class ArticleList extends BaseList
{
    public static $model = ArticleModel::class;

}
