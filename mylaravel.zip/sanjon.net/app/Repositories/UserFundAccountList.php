<?php

namespace App\Repositories;

use App\Models\UserFundAccount as UserFundAccountModel;

class UserFundAccountList extends BaseList
{
    public static $model = UserFundAccountModel::class;
}
