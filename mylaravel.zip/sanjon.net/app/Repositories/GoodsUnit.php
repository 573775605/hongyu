<?php

namespace App\Repositories;

use App\Models\GoodsUnit as GoodsUnitModel;

class GoodsUnit extends Base
{
    public static $modelName = GoodsUnitModel::class;

}
