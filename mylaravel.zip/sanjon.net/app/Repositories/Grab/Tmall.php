<?php

namespace App\Repositories\Grab;

/**
 * Created by PhpStorm.
 * User: wenlongh
 * Date: 2017/9/12
 * Time: 19:17
 * Author: wenlongh <wenlongh@qq.com>
 */
class Tmall extends Base
{

}