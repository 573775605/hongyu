<?php

namespace App\Repositories;

use App\Models\UserEvaluateLog as UserEvaluateLogModel;

class UserEvaluateLogList extends BaseList
{
    public static $model = UserEvaluateLogModel::class;
}
