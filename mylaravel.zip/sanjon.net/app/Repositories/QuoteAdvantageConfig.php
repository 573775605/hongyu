<?php

namespace App\Repositories;

use App\Models\QuoteAdvantageConfig as QuoteAdvantageConfigModel;

class QuoteAdvantageConfig extends Base
{
    public static $modelName = QuoteAdvantageConfigModel::class;

}
