<?php

namespace App\Repositories;

use App\Models\UserBalanceLog as UserBalanceLogModel;

class UserBalancelogList extends BaseList
{
    public static $model = UserBalanceLogModel::class;
}
