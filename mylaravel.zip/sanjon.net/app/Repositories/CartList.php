<?php

namespace App\Repositories;

use App\Models\Cart as CartModel;

class CartList extends BaseList
{
    public static $model = CartModel::class;
}
