<?php

namespace App\Repositories;

use App\Models\Article as ArticleModel;

class Article extends Base
{
    public static $modelName = ArticleModel::class;

}
