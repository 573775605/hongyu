<?php

namespace App\Repositories;

use App\Models\UserSpareLog as UserSpareLogModel;

class UserSpareLogList extends BaseList
{
    public static $model = UserSpareLogModel::class;
}
