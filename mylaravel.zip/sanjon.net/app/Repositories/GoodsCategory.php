<?php

namespace App\Repositories;

use App\Models\GoodsCategory as GoodsCategoryModel;

class GoodsCategory extends Base
{
    public static $modelName = GoodsCategoryModel::class;

}
