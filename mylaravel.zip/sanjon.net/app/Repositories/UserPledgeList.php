<?php

namespace App\Repositories;

use App\Models\UserPledgeLog as UserPledgeLogModel;

class UserPledgeList extends BaseList
{
    public static $model = UserPledgeLogModel::class;
}
