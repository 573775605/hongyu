<?php

namespace App\Repositories;

use App\Models\DemandGoods as DemandGoodsModel;

class DemandGoodsList extends BaseList
{

    public static $model = DemandGoodsModel::class;

}
