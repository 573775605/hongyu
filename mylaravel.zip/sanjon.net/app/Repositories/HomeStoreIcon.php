<?php

namespace App\Repositories;

use App\Models\HomeStoreIcon as HomeStoreIconModel;

class HomeStoreIcon extends Base
{
    public static $modelName = HomeStoreIconModel::class;

}
