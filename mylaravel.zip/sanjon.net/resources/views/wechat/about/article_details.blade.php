@extends('wechat.layout.master')

@section('title','文章详情')

@section('content')
    {!! $row->content !!}
@stop