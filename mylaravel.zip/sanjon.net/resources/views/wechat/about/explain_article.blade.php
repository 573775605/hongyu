@extends('wechat.layout.master')

@section('title','详细说明')

@section('content')
    {!! $content !!}
@stop