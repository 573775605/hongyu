<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>微信支付</title>
</head>
<body>

</body>
</html>
<script src="http://res.wx.qq.com/open/js/jweixin-1.2.0.js" type="text/javascript" charset="utf-8"></script>
<script>
    wx.config(<?php echo $js->config(['chooseWXPay'], false); ?>);

    wx.ready(function () {
        wx.chooseWXPay({
            timestamp: '<?php echo e($config['timestamp']); ?>',
            nonceStr: '<?php echo e($config['nonceStr']); ?>',
            package: '<?php echo e($config['package']); ?>',
            signType: '<?php echo e($config['signType']); ?>',
            paySign: '<?php echo e($config['paySign']); ?>', // 支付签名
            success: function (res) {
                location.href = '<?php echo e(url('wechat')); ?>';
            }
        });
    });
</script>