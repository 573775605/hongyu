<?php if(!empty($status)): ?>
    <?php if($status['status']===true): ?>
        <div class="alert alert-success">
            <a href="#" class="close" data-dismiss="alert">
                &times;
            </a>
            <?php echo e(isset($status['msg']) ? $status['msg'] : '保存成功'); ?>

        </div>
    <?php elseif($status['status']===false): ?>
        <div class="alert alert-warning">
            <a href="#" class="close" data-dismiss="alert">
                &times;
            </a>
            <?php echo e(isset($status['msg']) ? $status['msg'] : '保存失败'); ?>

        </div>
    <?php endif; ?>
<?php endif; ?>