<?php $__env->startSection('title','填写发货信息'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/wechat/css/photo.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p class="fabuing">收件人</p>
    <a class=" XQ2adress ">
        <div class="clearfix XQ2adressword1">
            <div class="fl">收货人：<?php echo e($demand->consignee); ?></div>
            <div class="fr"><?php echo e($demand->phone); ?></div>
        </div>
        <div class="XQ2adressword2 ellipsis2">
            收货地址：<?php echo e($demand->address); ?>

        </div>
    </a>

    <form action="" method="post" onsubmit="return checkSubmit()">
        <?php echo csrf_field(); ?>

        <dl class="offers clearfix">
            <dt class="mt5">快递公司：</dt>
            <dd>
                <div class="border jiantoub">
                    <select name="express_company_number" class="selects selectstext">
                        <?php foreach($express as $k=>$v): ?>
                            <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </dd>
        </dl>

        <dl class="offers clearfix">
            <dt class="mt5">物流单号：</dt>
            <dd>
                <div class="border ">
                    <input type="text" placeholder="输入物流单号" name="express_number"/>
                </div>
            </dd>
        </dl>

        <dl class="offers clearfix">
            <dt class="mt5">购买凭证：</dt>
            <dd>
                <ul class="cUl mt10 clearfix">
                    <li class="">
                        <input class="NO " type="file" name="file" id="file">
                        <div class="cadd"></div>
                    </li>
                </ul>
                <?php /*<div class=" cborder">*/ ?>
                <?php /*<input class="NO " type="file" name="file" id="file">*/ ?>
                <?php /*<div class="cadd">*/ ?>
                <?php /*<img src="<?php echo e(asset('asset/wechat/img/sc.png')); ?>"/>*/ ?>
                <?php /*</div>*/ ?>
                <?php /*</div>*/ ?>
                <p class="cbordertop">*如代购订单截图，结账小票，发票等</p>
            </dd>
        </dl>

        <a class="redbtn90">
            <input type="submit" value="确认发货"/>
        </a>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('asset/ext/layer/layer.min.js')); ?>"></script>
    <?php /*上传插件*/ ?>
    <script src="<?php echo e(asset("asset/ext/jquery-file-upload/vendor/jquery.ui.widget.js")); ?>"></script>
    <script src="<?php echo e(asset("asset/ext/jquery-file-upload/jquery.iframe-transport.js")); ?>"></script>
    <script src="<?php echo e(asset("asset/ext/jquery-file-upload/jquery.fileupload.js")); ?>"></script>
    <script>
        function checkSubmit() {
            if ($('input[name=express_number]').val() == '') {
                layer.msg('请填写物流单号');
                return false;
            }
            return true;
        }

        function creatImg(imgRUL, id) {
            var cul = $(".cUl");
            var textHtml = '<li class="goods-imgs"><img src="' + imgRUL + '"/><em class="cdel"></em>';
            textHtml += '<input type="hidden" name="imgs[]" value="' + id + '">';
            $(cul).prepend(textHtml);
        }

        $(".cadd").click(function () {
            $(this).siblings('input[type=file]').trigger("click");
        });

        $(".cUl").delegate(".cdel", "click", function () {
            $(this).parents("li").remove();
        })

        $('#file').fileupload({
            url: '<?php echo e(url('wechat/upload')); ?>',
            formData: {_token: '<?php echo e(csrf_token()); ?>'},
            //dataType: 'json',
            done: function (e, data) {
                creatImg(data.result.data.url, data.result.data.id);
//                console.log(data.result);
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>