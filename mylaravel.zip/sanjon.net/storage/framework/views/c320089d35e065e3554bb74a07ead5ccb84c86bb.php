<?php $__env->startSection('title','修改报价'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/wechat/css/AddSubtract.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(url('wechat/tender/edit-sub/'.$tender->id)); ?>" method="post" id="form">
        <?php echo csrf_field(); ?>

        <input type="hidden" name="hotboom_lng" value="<?php echo e(request('hotboom_lng')?:$tender->hotboom_lng); ?>">
        <input type="hidden" name="hotboom_lat" value="<?php echo e(request('hotboom_lat')?:$tender->hotboom_lat); ?>">
        <input type="hidden" name="hotboom_store_name" value="<?php echo e(request('hotboom_store_name')?:$tender->hotboom_store_name); ?>">
        <input type="hidden" name="type" value="<?php echo e(request('type')?:$tender->type); ?>">
        <?php if(request('advantage')): ?>
            <?php foreach(request('advantage',[]) as $k=>$v): ?>
                <?php if(isset($v['select'])): ?>
                    <?php foreach($v['select'] as $v1): ?>
                        <input type="hidden" name="advantage[<?php echo e($k); ?>][select][]" value="<?php echo e($v1); ?>">
                    <?php endforeach; ?>
                <?php endif; ?>
                <input type="hidden" name="advantage[<?php echo e($k); ?>][other]" value="<?php echo e($v['other']); ?>">
            <?php endforeach; ?>
        <?php else: ?>
            <?php foreach($tender->quoteAdvantage as $v): ?>
                <?php foreach(json_decode($v->label,true) as $v1): ?>
                    <input type="hidden" name="advantage[<?php echo e($v->name); ?>][select][]" value="<?php echo e($v1); ?>">
                <?php endforeach; ?>
                <input type="hidden" name="advantage[<?php echo e($v->name); ?>][other]" value="<?php echo e($v->other); ?>">
            <?php endforeach; ?>
        <?php endif; ?>
        <dl class="offers clearfix">
            <dt class="mt12"><em>*</em>报价金额(元)：</dt>
            <dd>
                <div class="border Daddress">
                    <input type="text" placeholder="您代购该订单收取的总价款" name="quote" value="<?php echo e(request('quote')?:$tender->quote); ?>"/>
                </div>
            </dd>
        </dl>

        <dl class="offers clearfix">
            <dt class="mt12"><em>*</em>邮费：</dt>
            <dd>
                <div class="border Daddress">
                    <input type="text" placeholder="0" name="express_price" value="<?php echo e(request('express_price')?:$tender->express_price); ?>"/>
                </div>
            </dd>
        </dl>
        <dl class="offers clearfix">
            <dt class="mt5"><em>*</em>报价优势：</dt>
            <dd>
                <a class="btnsqueryellow2">
                    <input type="button" value="选择" onclick="selectAdvantage()"/>
                </a>
            </dd>
        </dl>
        <dl class="offers clearfix">
            <dt class="mt5">库存数量：</dt>
            <dd>
                <div class="NBnumall clearfix ">
                    <span class="reduce"></span>
                    <input class="NBnumtext quantity" type="number" name="repertory" value="<?php echo e(request('repertory',$tender->repertory)); ?>">
                    <span class="plus"></span>
                </div>
            </dd>
        </dl>

        <dl class="offers clearfix">
            <dt class="mt5">代购有效期：</dt>
            <dd>
                <div class="NBnumall clearfix  ">
                    <span class="reduce"></span>
                    <input class="NBnumtext quantity" type="number" name="day" value="<?php echo e(request('day',$tender->getDay())); ?>">
                    <span class="timedate mr10">天</span>
                    <span class="plus"></span>
                </div>
                <div class="NBnumall clearfix mt15 ">
                    <span class="reduce"></span>
                    <input class="NBnumtext quantity" type="number" name="hour" value="<?php echo e(request('hour',$tender->getHour())); ?>">
                    <span class="timedate mr10">时</span>
                    <span class="plus"></span>
                </div>
            </dd>
        </dl>
    </form>

    <a class="redbtn90">
        <input type="button" value="确认报价" onclick="submitQuote()"/>
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        //选择报价优势
        function selectAdvantage() {
            var url = '<?php echo e(url('wechat/tender/select-advantage?tender_id='.$tender->id)); ?>'
            $('#form').attr('action', url);
            $('#form').submit();
        }
        //提交报价
        function submitQuote() {
            <?php /*var url = '<?php echo e(url('wechat/tender/submit')); ?>'*/ ?>
            <?php /*$('#form').attr('action', url);*/ ?>
            $('#form').submit();
        }

        function changeCount(obj, count, defaultVal) { //改变数量
            var nowCount = $(obj).find('.quantity').val();
            nowCount = parseInt(nowCount);
            if (nowCount + count > 0) {
                $(obj).find('.quantity').val(nowCount + count);
            } else {
                $(obj).find('.quantity').val(defaultVal);
            }
        }

        $('.plus').click(function () {//加
            var divObj = $(this).parent('.NBnumall');
            changeCount(divObj, 1, 1);
        })
        $('.reduce').click(function () {//减
            var divObj = $(this).parent('.NBnumall');
            if ($(divObj).find('.quantity').attr('name') == 'day') {
                changeCount(divObj, -1, 0);
            } else {
                changeCount(divObj, -1, 1);
            }
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>