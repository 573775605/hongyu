<?php $__env->startSection('title','报价人信息'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/ext/dropload/dropload.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body','bgf9'); ?>

<?php $__env->startSection('content'); ?>
    <div class="InformationView">
        <div class="InformationViewimg">
            <img src="<?php echo e(asset('asset/wechat/img/3.png')); ?>"/>
        </div>
        <div class="InformationViewicon">
            <img src="<?php echo e(isset($tender->user->img_url) ? $tender->user->img_url : ''); ?>"/>
        </div>
    </div>
    <div class="IVadress">
        <p class="ellipsis1 IVadressword1"><?php echo e(isset($tender->user->nickname) ? $tender->user->nickname : ''); ?></p>
        <p class="ellipsis1 IVadressword2"><?php echo e($tender->getSite()); ?></p>
    </div>

    <p class="IVtit">红利资源</p>
    <div class="ellipsis1 IVresourcesword ">
        <?php echo e(isset($tender->user->userInfo->description) ? $tender->user->userInfo->description : ''); ?>

    </div>
    <div class="clearfix evaluateall">
        <div class="fl evaluate">
            收到的评价
        </div>
        <a class="fr evaluateMore" href="<?php echo e(url('wechat/user/all-evaluate/hotboom/'.$tender->user_id)); ?>">
            更多评价
        </a>
    </div>
    <ul class="evaluateUl ">
        <?php foreach($evaluate as $v): ?>
            <li class="clearfix">
                <div class="evaluateUlimg">
                    <img src="<?php echo e(isset($v->evaluateUser->img_url) ? $v->evaluateUser->img_url : ''); ?>"/>
                </div>
                <div class="evaluateUlR">
                    <div class="clearfix evaluateUltit">
                        <div class="fl evaluateUltit1">
                            <span class="ellipsis1"><?php echo e(isset($v->evaluateUser->nickname) ? $v->evaluateUser->nickname : ''); ?></span>
                        </div>
                        <div class="fr evaluateUltit2">
                            <span class="ellipsis1"><?php echo e($v->create_time); ?></span>
                        </div>
                    </div>
                    <div class="evaluateUltit3 ellipsis1">
                        <?php echo e($v->content); ?>

                    </div>
                </div>
            </li>
        <?php endforeach; ?>
    </ul>
    <p class="fabuing">参加报价</p>
    <div id="dropload">
        <ul class="fubuimgList clearfix" id="list">
            <?php foreach($demand as $v): ?>
                <li>
                    <a href="<?php echo e(url('wechat/tender/demand-details/'.$v->id)); ?>">
                        <?php /*<div class="timespan2" id="time<?php echo e($v->id); ?>">*/ ?>
                        <?php /*<span class="day_show">0</span><em>天</em>*/ ?>
                        <?php /*<span class="hour_show"><s id="h"></s>0</span><em>时</em>*/ ?>
                        <?php /*<span class="minute_show"><s></s>0</span><em>分</em>*/ ?>
                        <?php /*<span class="second_show"><s></s>0</span><em>秒</em>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php if($v->demandGoods&&$v->demandGoods->first()): ?>
                            <div class="fubuimgListimg">
                                <img src="<?php echo e(isset($v->demandGoods->first()->img->url) ? $v->demandGoods->first()->img->url : ''); ?>"/>
                            </div>
                            <div class="fubuimgListword1 ellipsis1"><?php echo e($v->demandGoods->first()->name); ?></div>
                            <p class="fubuimgListword2">￥<?php echo e($v->demandGoods->first()->price); ?></p>
                            <div class="clearfix ">
                                <div class="fubuimgListword3">
                                    <div class="ellipsis1 fubuimgListword3icon"><?php echo e($v->getIssueSite()); ?></div>
                                </div>
                                <div class="fubuimgListword4"><?php echo e($v->issue_time); ?></div>
                            </div>
                        <?php endif; ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('asset/ext/dropload/dropload.min.js')); ?>"></script>
    <script>
        var page = 2, pageTotal =<?php echo e($evaluate->lastPage()); ?>;
        $('#dropload').dropload({
            scrollArea: window,
            domDown: {
                domClass: "dropload-down",
                domRefresh: '<div class="dropload-refresh" style="display: none;">↑上拉加载更多</div>',
                domLoad: '<div class="dropload-load"><span class="loading"></span>加载中...</div>',
                domNoData: '<div class="dropload-noData"><?php echo e($evaluate->lastPage()?'没有更多数据':'暂无数据'); ?></div>'
            },
            loadDownFn: function (me) {
                $.post("<?php echo e(url('wechat/user/hotboom-info/'.$tender->id)); ?>",
                    {_token: '<?php echo e(csrf_token()); ?>', page: page},
                    function (data, status) {
                        $('#list').append(data.data.rows);
                        page++;
                        if (page > pageTotal) {
                            // 锁定
                            me.lock();
                            // 无数据
                            me.noData();
                        }
                        me.resetload();
                    });
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>