<?php $__env->startSection('title','商家地址'); ?>

<?php $__env->startSection('css'); ?>
    <style type="text/css">
        * {
            margin: 0px;
            padding: 0px;
        }

        body, button, input, select, textarea {
            font: 12px/16px Verdana, Helvetica, Arial, sans-serif;
        }

        #info {
            width: 603px;
            padding-top: 3px;
            overflow: hidden;
        }

        .btn {
            width: 112px;
        }

        #container {
            min-width: 600px;
            min-height: 767px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="dingweiall">
        <?php /*<span class="dingweiNum">距您：24km</span>*/ ?>

    </div>
    <div class="map" id="container">

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script charset="utf-8" src="http://map.qq.com/api/js?v=2.exp"></script>
    <script>
        var center = new qq.maps.LatLng(<?php echo e(isset($goods->store_lat) ? $goods->store_lat : request('lat')); ?>, <?php echo e(isset($goods->store_lng) ? $goods->store_lng : request('lng')); ?>);
        var map = new qq.maps.Map(document.getElementById('container'), {
            center: center,
            zoom: 13
        });
        //创建marker
        var marker = new qq.maps.Marker({
            position: center,
            map: map
        });
        var label = new qq.maps.Label({
            position: center,
            map: map,
            content: '<?php echo e(isset($goods)?$goods->getSite().'('.$goods->store_name.')':request('address').'('.request('name').')'); ?>'
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>