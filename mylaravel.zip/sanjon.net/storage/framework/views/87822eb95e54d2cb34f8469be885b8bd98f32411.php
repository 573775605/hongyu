<input type="hidden" name="goods_name" value="<?php echo e(isset($result['name']) ? $result['name'] : ''); ?>">
<input type="hidden" name="price" value="<?php echo e(isset($result['price']) ? $result['price'] : ''); ?>">
<input type="hidden" name="link" value="<?php echo e($url); ?>">
<input type="hidden" name="domain" value="<?php echo e($domain); ?>">
<?php if(!empty($result['img'])): ?>
    <?php foreach($result['img'] as $k=>$v): ?>
        <input type="hidden" name="imgs[<?php echo e($k); ?>][id]" value="<?php echo e(isset($v['id']) ? $v['id'] : ''); ?>">
        <input type="hidden" name="imgs[<?php echo e($k); ?>][url]" value="<?php echo e(isset($v['url']) ? $v['url'] : ''); ?>">
    <?php endforeach; ?>
<?php endif; ?>