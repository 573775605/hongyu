<!--导航-->
<div class="h100"></div>
<div class="nav">
    <a href="<?php echo e(url('wechat')); ?>" class="home <?php echo e($active=='home'?'active':''); ?>">
        <span></span>
        <em>首页</em>
    </a>
    <a href="<?php echo e(url('wechat/demand/filter')); ?>" class="redcity <?php echo e($active=='filter'?'active':''); ?>">
        <span></span>
        <em>红市</em>
    </a>
    <a href="<?php echo e(url('wechat/address')); ?>?type=issue-demand">
        <em class="fabu"></em>
    </a>
    <a href="<?php echo e(url('wechat/message/index')); ?>" class="news <?php echo e($active=='message'?'active':''); ?>">
        <span></span>
        <em>消息</em>
    </a>
    <a href="<?php echo e(url('wechat/center')); ?>" class="mine <?php echo e($active=='center'?'active':''); ?>">
        <span></span>
        <em>我的</em>
    </a>
</div>