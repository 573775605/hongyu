<?php $__env->startSection('title','选择货源'); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .mui-row.mui-fullscreen > [class*="mui-col-"] {
            height: 100%;
        }

        .mui-col-xs-3, .mui-col-xs-9 {
            overflow-y: auto;
            height: 100%;
        }

        .mui-segmented-control .mui-control-item {
            line-height: 50px;
            width: 100%;
        }

        .mui-control-content {
            display: block;
        }

        .mui-segmented-control.mui-segmented-control-inverted .mui-control-item.mui-active {
            background-color: #fff;
        }

        #segmentedControlContents {
            background-color: #fff;
        }

        .mui-segmented-control.mui-segmented-control-inverted .mui-control-item.mui-active {
            background: transparent;
        }

        .mui-segmented-control.mui-segmented-control-inverted .mui-control-item {
            background-color: #fff;
        }

        .mui-segmented-control.mui-segmented-control-inverted.mui-segmented-control-vertical .mui-control-item,
        .mui-segmented-control.mui-segmented-control-inverted.mui-segmented-control-vertical .mui-control-item.mui-active {
            border-bottom: 1px solid #f1f1f1;
        }

        .mui-control-content {
            display: none;
        }

        #segmentedControlContents .mui-control-content.active {
            display: block;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body','bgf9 mui-ios'); ?>
<?php $__env->startSection('content'); ?>
    <div class="mui-content mui-row mui-fullscreen">
        <div class="mui-col-xs-3">
            <div id="segmentedControls" class="Listnav mui-segmented-control mui-segmented-control-inverted mui-segmented-control-vertical">
                <?php foreach($rows->whereLoose('level',1)->values() as $k=>$v): ?>
                    <a class="mui-control-item <?php echo e($k?'':'mui-active'); ?>"><?php echo e($v->name); ?></a>
                <?php endforeach; ?>
            </div>
        </div>
        <div id="segmentedControlContents" class="mui-col-xs-9">
            <?php foreach($rows->whereLoose('level',1)->values() as $k=>$v): ?>
                <div id="content" class="mui-control-content <?php echo e($k?'':'mui-active'); ?>">
                    <ul class="mui-table-view ListR ListPading">
                        <?php foreach($rows as $v1): ?>
                            <?php if($v1->parent_id==$v->id): ?>
                                <?php if(request('goods_id')): ?>
                                    <li>
                                        <a href="<?php echo e(url('wechat/demand/edit/'.request('goods_id').'?source='.$v1->name.'&source_id='.$v1->id)); ?>">
                                            <div class="Listimg"><img src="<?php echo e(isset($v1->img->url) ? $v1->img->url : ''); ?>"/></div>
                                            <p class="listword2"><?php echo e($v1->name); ?></p>
                                        </a>
                                    </li>
                                <?php else: ?>
                                    <li>
                                        <a href="<?php echo e(url('wechat/issue/index?source='.$v1->name.'&source_id='.$v1->id)); ?>">
                                            <div class="Listimg"><img src="<?php echo e(isset($v1->img->url) ? $v1->img->url : ''); ?>"/></div>
                                            <p class="listword2"><?php echo e($v1->name); ?></p>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; ?>

                    </ul>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(function () {
            var Listimgw = $(".Listimg").width();
            $(".Listimg").css("height", Listimgw);

            $("#segmentedControls a").click(function () {//列表切换
                var i = $("#segmentedControls a").index($(this));
                $("#segmentedControls a").removeClass("mui-active");
                $(this).addClass("mui-active");
                $("#segmentedControlContents div.mui-control-content").removeClass("mui-active");
                $("#segmentedControlContents div.mui-control-content").eq(i).addClass("mui-active");
            })
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>