<?php foreach($rows as $v): ?>
    <li>
        <div class="Uneedtit clearfix">
            <span class="Uword2" style="width: 100%;" >订单号:
                <?php /*<em id="content" value="<?php echo e($v->order_number); ?>"><?php echo e($v->order_number); ?></em>*/ ?>
                <input type="text" readonly="text" value="<?php echo e($v->order_number); ?>">
                <?php /*<em class="Ucopy" id="copyBT">复制</em></span>*/ ?>
            <span class="Uorder">订单总额:<em class="Iprice">¥<?php echo e($v->known_price); ?></em></span>
            <span class="Idistance"><?php echo e($v->create_time); ?></span>
        </div>
        <?php if($v->demandGoods && $v->demandGoods->first()): ?>
            <a href="<?php echo e(url('wechat/hotboom-demand/details/'.$v->id)); ?>">
                <div class="Uneedcont clearfix">
                    <div class="Uneedcontimg ">
                        <img src="<?php echo e(isset($v->demandGoods->first()->img->url) ? $v->demandGoods->first()->img->url : ''); ?>">
                    </div>
                    <div class="fl Uneedcontwords">
                        <p class="Uneedcontwords1 ellipsis1"><?php echo e($v->demandGoods->first()->name); ?></p>
                        <p class="Uneedcontwords2"><em class="Uneedred1">¥<?php echo e($v->demandGoods->first()->known_unit_price); ?></em> /
                            *<?php echo e($v->demandGoods->first()->count); ?><?php echo e($v->demandGoods->first()->unit); ?></p>
                        <p class="Uneedcontwords3 clearfix"><span class="fl"><?php echo e($v->getIssueSite()); ?></span></p>
                    </div>
                </div>
            </a>
        <?php endif; ?>
        <div class="clearfix Uneedtime">
            <?php if(!$v->is_pay): ?>
                <div class="timespan" id="time<?php echo e(request('status')); ?><?php echo e($v->id); ?>">
                    <?php if($v->status==1): ?>
                        <span class="day_show">0</span>&nbsp;<em>天</em>
                    <?php endif; ?>
                    <span class="hour_show"><s id="h"></s>0</span>&nbsp;<em>时</em>
                    <span class="minute_show"><s></s>0</span>&nbsp;<em>分</em>
                    <span class="second_show"><s></s>0</span>&nbsp;<em>秒</em>
                </div>
                <script>
                    timer(<?php echo e($v->pay_end_time-time()); ?>, '#time<?php echo e(request('status')); ?><?php echo e($v->id); ?>');
                </script>
            <?php endif; ?>
            <div class="orderButtonyellow fr">
                <?php if($v->status==-2): ?>
                    <input type="button" value="<?php echo e($status[$v->status].'('.$returnStatus[$v->returnGoodsApply->status].')'); ?>">
                <?php elseif($v->status!=5): ?>
                    <input type="button" value="<?php echo e(isset($status[$v->status]) ? $status[$v->status] : ''); ?>">
                <?php else: ?>
                    <input type="button" value="<?php echo e($v->daigou_evaluate?'已完成':'待评价'); ?>">
                <?php endif; ?>
            </div>
        </div>
    </li>
<?php endforeach; ?>

