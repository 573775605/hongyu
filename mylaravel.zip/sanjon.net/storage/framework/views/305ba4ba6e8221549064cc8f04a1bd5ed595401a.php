<?php $__env->startSection('title','参加报价需求'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/ext/dropload/dropload.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="mui-content">
        <div id="dropload">
            <ul class="mui-table-view OrderlistUl" id="list">
                <?php foreach($rows as $v): ?>
                    <li>
                        <div class="Uneedtit clearfix">
                            <span class="Uword2">订单号:  <input type="text" readonly="text" value=" <?php echo e(isset($v->demand->order_number) ? $v->demand->order_number : ''); ?>"> </span>
                            <span class="Uorder">订单总额:<em class="Iprice">¥<em class="Iprice2"><?php echo e(isset($v->demand->known_price) ? $v->demand->known_price : ''); ?></em></em></span>
                            <span class="Idistance"><?php echo e(isset($v->demand->create_time) ? $v->demand->create_time : ''); ?></span>
                        </div>

                        <div class="Uneedcont clearfix" onclick="location.href='<?php echo e(url('wechat/tender/demand-details/'.$v->demand_id.'?tender_id='.$v->id)); ?>'">
                            <div class="Uneedcontimg ">
                                <img src="<?php echo e(isset($v->demand->demandGoods->first()->img->url) ? $v->demand->demandGoods->first()->img->url : ''); ?>">
                            </div>
                            <div class="fl Uneedcontwords">
                                <p class="Uneedcontwords1 ellipsis1"><?php echo e(isset($v->demand->demandGoods->first()->name) ? $v->demand->demandGoods->first()->name : ''); ?></p>
                                <p class="Uneedcontwords2">
                                    <em class="Uneedred1">¥<span class="Uneedred2"><?php echo e(isset($v->demand->demandGoods->first()->known_unit_price) ? $v->demand->demandGoods->first()->known_unit_price : ''); ?></span></em> /
                                    *<?php echo e(isset($v->demand->demandGoods->first()->count) ? $v->demand->demandGoods->first()->count : ''); ?><?php echo e(isset($v->demand->demandGoods->first()->unit) ? $v->demand->demandGoods->first()->unit : ''); ?></p>
                                <p class="Uneedcontwords3 clearfix">
                                    <span class="fl"><?php echo e($v->demand->getIssueSite()); ?></span></p>
                            </div>
                        </div>

                        <div class="clearfix Uneedtime">
                            <div class="Orderwgreen fl "><?php echo e(isset($status[$v->status]) ? $status[$v->status] : ''); ?></div>
                            <?php if($v->status==1): ?>
                                <div class="timespan fl" id="time<?php echo e($v->id); ?>">
                                    <span class="day_show">0</span>&nbsp;<em>天</em>
                                    <span class="hour_show"><s id="h"></s>0</span>&nbsp;<em>时</em>
                                    <span class="minute_show"><s></s>0</span>&nbsp;<em>分</em>
                                    <span class="second_show"><s></s>0</span>&nbsp;<em>秒</em>
                                </div>
                            <?php endif; ?>
                            <?php if($v->status==1|$v->status==3): ?>
                                <div class="orderButtongreen fr mt5   ">
                                    <input type="button" value="<?php echo e(isset($demandStatus[$v->demand->status]) ? $demandStatus[$v->demand->status] : ''); ?>">
                                </div>
                            <?php endif; ?>
                            <?php if($v->isDelete()): ?>
                                <a class="orderButtongred fr mt5" href="javascript:removeTender('<?php echo e(route('tenderDelete',['id'=>$v->id])); ?>')">
                                    <input type="button" value="删除">
                                </a>
                            <?php endif; ?>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('asset/ext/dropload/dropload.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/ext/layer/layer.min.js')); ?>"></script>
    <script>
        function removeTender(url) {
            layer.confirm('确认删除吗？', {
                btn: ['确认', '取消']
            }, function (index, layero) {
                $.ajax({
                    type: 'DELETE',
                    url: url,
                    data: {_token: '<?php echo e(csrf_token()); ?>'},
                    dataType: 'json',
                    success: function (data) {
                        if (data.status != 1) {
                            layer.msg('删除失败' + data.message);
                            return false;
                        } else {
                            location.reload();
                        }
                    },
                    error: function (xhr, type) {
                        layer.msg('删除失败' + xhr.message);
                    },
                });
            }, function (index) {
                //按钮【按钮二】的回调
            });
        }

        function timer(intDiff, obj) {//倒计时
            window.setInterval(function () {
                var day = 0,
                    hour = 0,
                    minute = 0,
                    second = 0;//时间默认值
                if (intDiff > 0) {
                    day = Math.floor(intDiff / (60 * 60 * 24));
                    hour = Math.floor(intDiff / (60 * 60)) - (day * 24);
                    minute = Math.floor(intDiff / 60) - (day * 24 * 60) - (hour * 60);
                    second = Math.floor(intDiff) - (day * 24 * 60 * 60) - (hour * 60 * 60) - (minute * 60);
                }
                if (minute <= 9) minute = '0' + minute;
                if (second <= 9) second = '0' + second;
                $(obj + ' .day_show').html(day);
                $(obj + ' .hour_show').html('<s id="h"></s>' + hour);
                $(obj + ' .minute_show').html('<s></s>' + minute);
                $(obj + ' .second_show').html('<s></s>' + second);
                intDiff--;
            }, 1000);
        }

        $(function () {
            <?php foreach($rows as $v): ?>
            timer(parseInt(<?php echo e($v->demand->end_time-time()); ?>), "#time<?php echo e($v->id); ?>");
            <?php endforeach; ?>
        })
        var page = 2, pageTotal =<?php echo e($rows->lastPage()); ?>;
        $('#dropload').dropload({
            scrollArea: window,
            domDown: {
                domClass: "dropload-down",
                domRefresh: '<div class="dropload-refresh" style="display: none;">↑上拉加载更多</div>',
                domLoad: '<div class="dropload-load"><span class="loading"></span>加载中...</div>',
                domNoData: '<div class="dropload-noData"><?php echo e($rows->lastPage()?'没有更多数据':'暂无数据'); ?></div>'
            },
            loadDownFn: function (me) {
                $.post("<?php echo e(url('wechat/center/tender-list')); ?>",
                    {_token: '<?php echo e(csrf_token()); ?>', page: page},
                    function (data, status) {
                        $('#list').append(data.data.rows);
                        page++;
                        if (page > pageTotal) {
                            // 锁定
                            me.lock();
                            // 无数据
                            me.noData();
                        }
                        me.resetload();
                    });
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>