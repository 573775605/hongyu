<?php $__env->startSection('title','意见反馈'); ?>

<?php $__env->startSection('content'); ?>
    <form action="" method="post" onsubmit="return submitCheck()">
        <?php echo csrf_field(); ?>

        <dl class="offers clearfix">
            <dt class="mt5">意见和投诉：</dt>
            <dd>
                <div class="OrderLotextarea">
                    <textarea placeholder="请输入问题或意见" name="content"></textarea>
                </div>
            </dd>
        </dl>
        <a class="redbtn90">
            <input type="submit" value="提交"/>
        </a>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('asset/ext/layer/layer.min.js')); ?>"></script>
    <script>
        function submitCheck() {
            if ($('textarea[name=content]').val() == '') {
                layer.msg('请描述相关内容');
                return false;
            }
            return true;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>