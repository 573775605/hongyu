<?php /*<?php foreach($rows as $v): ?>*/ ?>
<?php /*<li class="clearfix">*/ ?>
<?php /*<div class="evaluateUlimg">*/ ?>
<?php /*<img src="<?php echo e(isset($v->evaluateUser->img_url) ? $v->evaluateUser->img_url : ''); ?>"/>*/ ?>
<?php /*</div>*/ ?>
<?php /*<div class="evaluateUlR">*/ ?>
<?php /*<div class="clearfix evaluateUltit">*/ ?>
<?php /*<div class="fl evaluateUltit1">*/ ?>
<?php /*<span class="ellipsis1"><?php echo e(isset($v->evaluateUser->nickname) ? $v->evaluateUser->nickname : ''); ?></span>*/ ?>
<?php /*</div>*/ ?>
<?php /*<div class="fr evaluateUltit2">*/ ?>
<?php /*<span class="ellipsis1"><?php echo e($v->create_time); ?></span>*/ ?>
<?php /*</div>*/ ?>
<?php /*</div>*/ ?>
<?php /*<div class="evaluateUltit3 ellipsis1">*/ ?>
<?php /*<?php echo e($v->content); ?>*/ ?>
<?php /*</div>*/ ?>
<?php /*</div>*/ ?>
<?php /*</li>*/ ?>
<?php /*<?php endforeach; ?>*/ ?>
<?php foreach($rows as $v): ?>
    <li>
        <a href="<?php echo e(url('wechat/tender/demand-details/'.$v->id)); ?>">
            <?php /*<div class="timespan2" id="time<?php echo e($v->id); ?>">*/ ?>
            <?php /*<span class="day_show">0</span><em>天</em>*/ ?>
            <?php /*<span class="hour_show"><s id="h"></s>0</span><em>时</em>*/ ?>
            <?php /*<span class="minute_show"><s></s>0</span><em>分</em>*/ ?>
            <?php /*<span class="second_show"><s></s>0</span><em>秒</em>*/ ?>
            <?php /*</div>*/ ?>
            <?php if($v->demandGoods&&$v->demandGoods->first()): ?>
                <div class="fubuimgListimg">
                    <img src="<?php echo e(isset($v->demandGoods->first()->img->url) ? $v->demandGoods->first()->img->url : ''); ?>"/>
                </div>
                <div class="fubuimgListword1 ellipsis1"><?php echo e($v->demandGoods->first()->name); ?></div>
                <p class="fubuimgListword2">￥<?php echo e($v->demandGoods->first()->price); ?></p>
                <div class="clearfix ">
                    <div class="fubuimgListword3">
                        <div class="ellipsis1 fubuimgListword3icon"><?php echo e($v->getIssueSite()); ?></div>
                    </div>
                    <div class="fubuimgListword4"><?php echo e($v->issue_time); ?></div>
                </div>
            <?php endif; ?>
        </a>
    </li>
<?php endforeach; ?>