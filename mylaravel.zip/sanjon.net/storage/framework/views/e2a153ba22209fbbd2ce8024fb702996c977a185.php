<?php $__env->startSection('title','关于我们'); ?>

<?php $__env->startSection('content'); ?>
    <ul class="aboutUs">
        <?php foreach($rows as $v): ?>
            <li class="jiantou"><a href="<?php echo e(url('wechat/about/article-details/'.$v->id)); ?>"><?php echo e($v->title); ?></a></li>
        <?php endforeach; ?>
            <li class="jiantou"><a href="<?php echo e(url('wechat/user/feedback')); ?>">意见和投诉</a></li>
    </ul>
    <style>
        .aboutUs li{            width: 100%;}

    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>