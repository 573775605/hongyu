<?php $__env->startSection('title','余额明细'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/wechat/css/mingxi.css')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/ext/dropload/dropload.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="dropload">
        <ul class="MlevelList" id="list">
            <?php foreach($rows as $v): ?>
                <li>
                    <p class="MlevelListword1"><?php echo e($v->create_time); ?></p>
                    <div class="MlevelListword2">
                        <?php if($v->demand_id): ?>
                            <dl class="MXdlall borderB clearfix">
                                <dt>订单号：</dt>
                                <dd><?php echo e($v->demand->order_number); ?></dd>
                            </dl>
                        <?php endif; ?>
                        <dl class="MXdlall clearfix">
                            <dt><?php echo e($v->remark); ?>：</dt>
                            <dd><span class="<?php echo e($v->change_balance>0?'Mlevelgreen':'Mlevelred'); ?>">¥<?php echo e($v->change_balance); ?></span></dd>
                        </dl>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('asset/ext/dropload/dropload.min.js')); ?>"></script>
    <script>
        var page = 2, pageTotal =<?php echo e($rows->lastPage()); ?>;
        $('#dropload').dropload({
            scrollArea: window,
            domDown: {
                domClass: "dropload-down",
                domRefresh: '<div class="dropload-refresh" style="display: none;">↑上拉加载更多</div>',
                domLoad: '<div class="dropload-load"><span class="loading"></span>加载中...</div>',
                domNoData: '<div class="dropload-noData"><?php echo e($rows->lastPage()?'没有更多数据':'暂无数据'); ?></div>'
            },
            loadDownFn: function (me) {
                $.post("<?php echo e(url('wechat/wallet/balance-log')); ?>",
                    {_token: '<?php echo e(csrf_token()); ?>', page: page},
                    function (data, status) {
                        $('#list').append(data.data.rows);
                        page++;
                        if (page > pageTotal) {
                            // 锁定
                            me.lock();
                            // 无数据
                            me.noData();
                        }
                        me.resetload();
                    });
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>