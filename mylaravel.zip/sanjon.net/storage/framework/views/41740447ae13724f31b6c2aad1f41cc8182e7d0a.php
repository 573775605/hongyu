<?php $__env->startSection('title','发布需求'); ?>

<?php $__env->startSection('mui-css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(url('wechat/issue/index')); ?>" onsubmit="return submitCheck()">
        <input type="hidden" name="action" value="type">
        <div class="clearfix paiall">
            <a class="fl pai" href="<?php echo e(url('wechat/issue/index?type=upload&action=type')); ?>">
                拍摄/相册
                <input type="radio" name="type" value="upload" style="display: none;">
            </a>
            <a class="fr lian" href="<?php echo e(url('wechat/issue/index?type=link&action=type')); ?>">
                商品链接
                <input type="radio" name="type" value="link" style="display: none;">
            </a>
        </div>
        <?php /*<a class="redbtn90" style="position: fixed; bottom: 10px;left:0px; ">*/ ?>
        <?php /*<input type="submit" value="确认"/>*/ ?>
        <?php /*</a>*/ ?>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('asset/ext/layer/layer.min.js')); ?>"></script>
    <script type="text/javascript">
        function submitCheck() {
            if ($('input[name=type]:checked').length == 0) {
                layer.msg('请选择发布类型');
                return false;
            }
            return true;
        }
        $(function () {
            $(".paiall a").click(function () {
                $(".paiall a").removeClass("active");
                $(this).addClass("active");
                $(this).find('input').prop('checked', true);
            })
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>