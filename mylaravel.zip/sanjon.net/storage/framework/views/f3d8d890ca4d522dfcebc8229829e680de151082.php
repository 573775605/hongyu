<div class="clearfix chartcont">
    <div class="touxiangimgR">
        <img src="<?php echo e(isset($user->img_url) ? $user->img_url : ''); ?>"/>
    </div>
    <div class="fr chartmine">
        <?php echo e($content->content); ?>

        <?php if($content->img): ?>
            <img src="<?php echo e($content->img->url); ?>"/>
        <?php endif; ?>
    </div>
    <div class="clearfix"></div>
    <p class="fr chartMtime"><?php echo e($content->create_time); ?></p>
</div>