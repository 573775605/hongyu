<?php foreach($message as $v): ?>
    <?php if($user->id==$v->send_user_id): ?>
        <div class="clearfix chartcont">
            <div class="touxiangimgR">
                <img src="<?php echo e(isset($v->sendUser->img_url) ? $v->sendUser->img_url : ''); ?>"/>
            </div>
            <div class="fr chartmine">
                <?php if(filter_var($v->content,FILTER_VALIDATE_URL)): ?>
                    <a href="<?php echo e($v->content); ?>"><?php echo e($v->content); ?></a>
                <?php else: ?>
                    <input type="text" readonly="readonly" value="<?php echo e($v->content); ?>">
                <?php endif; ?>
                <?php if($v->img): ?>
                    <img src="<?php echo e($v->img->url); ?>"/>
                <?php endif; ?>
            </div>
            <div class="clearfix"></div>
            <p class="fr chartMtime"><?php echo e($v->create_time); ?></p>
        </div>
    <?php else: ?>
        <div class="clearfix chartcont">
            <div class="touxiangimgL">
                <img src="<?php echo e(isset($v->sendUser->img_url) ? $v->sendUser->img_url : ''); ?>"/>
            </div>
            <div class="fl chartother">
                <?php if(filter_var($v->content,FILTER_VALIDATE_URL)): ?>
                    <a href="<?php echo e($v->content); ?>"><?php echo e($v->content); ?></a>
                <?php else: ?>
                    <input type="text" readonly="readonly" value="<?php echo e($v->content); ?>">
                <?php endif; ?>
                <?php if($v->img): ?>
                    <img src="<?php echo e($v->img->url); ?>"/>
                <?php endif; ?>
            </div>
            <div class="clearfix"></div>
            <p class="fl chartOtime"><?php echo e($v->create_time); ?></p>
        </div>
    <?php endif; ?>
<?php endforeach; ?>
