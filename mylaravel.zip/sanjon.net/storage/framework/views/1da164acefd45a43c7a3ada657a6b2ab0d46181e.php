<?php $__env->startSection('title','商品浏览'); ?>

<?php $__env->startSection('css'); ?>
    <style type="text/css">
        .TShareTwo {
            position: absolute;
            top: 0;
            right: 10px;
            width: 70%;
            z-index: 999;
        }

        .TShareTwo img {
            width: 100%;
        }

        .bg {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            background-color: #000;
            -moz-opacity: 0.4;
            -webkit-opacity: 0.4;
            opacity: 0.4;
        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg"></div>
    <div class="TShareTwo">
        <img src="<?php echo e(asset('asset/wechat/img/tips2.png')); ?>"/>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('asset/ext/layer/layer.min.js')); ?>"></script>
    <script>
        $(function () {
            //获取页面内容高度
            var wH = $(document).height();
            $(".bg").css("height", wH);

            //点击背景关闭分享
            $(".bg").click(function () {
                $(".TShareTwo,.bg").hide();
            })

            $(".TShareTwo,.bg").show();
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>