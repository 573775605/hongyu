<?php $__env->startSection('title','评价详情'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/ext/dropload/dropload.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/wechat/css/mingxi.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="dropload">
        <ul class="MlevelList" id="list">
            <?php foreach($evaluate as $v): ?>
                <li>
                    <p class="MlevelListword1"><?php echo e($v->create_time); ?></p>
                    <div class="MlevelListword2">
                        <dl class="MXdlall borderB clearfix">
                            <dt>订单号：</dt>
                            <dd><?php echo e(isset($v->demand->order_number) ? $v->demand->order_number : ''); ?></dd>
                        </dl>

                        <dl class="MXdlall clearfix">
                            <dt>购买商品获得：</dt>
                            <?php if(request('type')=='issue'): ?>
                                <dd><span class="Mlevelgreen">+ <?php echo e($v->grade); ?></span></dd>
                            <?php else: ?>
                                <dd><span class="Mlevelgreen">+ <?php echo e($v->avg_grade); ?></span></dd>
                            <?php endif; ?>
                        </dl>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('asset/ext/dropload/dropload.min.js')); ?>"></script>
    <script>
        var page = 2, pageTotal =<?php echo e($evaluate->lastPage()); ?>;
        $('#dropload').dropload({
            scrollArea: window,
            domDown: {
                domClass: "dropload-down",
                domRefresh: '<div class="dropload-refresh" style="display: none;">↑上拉加载更多</div>',
                domLoad: '<div class="dropload-load"><span class="loading"></span>加载中...</div>',
                domNoData: '<div class="dropload-noData"><?php echo e($evaluate->lastPage()?'没有更多数据':'暂无数据'); ?></div>'
            },
            loadDownFn: function (me) {
                $.post("<?php echo e(url('wechat/center/evaluate-grade-log?type='.request('type'))); ?>",
                    {_token: '<?php echo e(csrf_token()); ?>', page: page},
                    function (data, status) {
                        $('#list').append(data.data.rows);
                        page++;
                        if (page > pageTotal) {
                            // 锁定
                            me.lock();
                            // 无数据
                            me.noData();
                        }
                        me.resetload();
                    });
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>