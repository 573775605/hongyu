<?php $__env->startSection('title','用户发布信息'); ?>
<?php $__env->startSection('body','bgf9'); ?>
<?php $__env->startSection('content'); ?>
    <div id="testel">
        <div class="clearfix User">
            <div class="fl UserL clearfix">
                <div class="fl Userimg">
                    <img src="<?php echo e($user->img_url); ?>"/>
                </div>
                <div class="fl ">
                    <p class="ellipsis1 Userword1"><?php echo e($user->nickname); ?></p>
                    <p class="ellipsis1 Userword2">成交笔数: <em class="green"><?php echo e($user->issue_over_demand); ?></em></p>
                    <p class="ellipsis1 Userword3"><?php echo e($demand::countTimeInterval($user->update_time)); ?>来过</p>
                </div>
            </div>
            <div class="fr UserR clearfix">
                <p class="clearfix fr">
                    <span class="fl">红利需求信誉</span><em class="fl Astart<?php echo e($user->daigou_evaluate_avg_grade); ?>" style="margin-top:8px; margin-left: 5px;"></em></p>
                <?php /*<p class="clearfix fr">*/ ?>
                <?php /*<span class="fl">红利分享信誉</span><em class="fl Astart<?php echo e($user->evaluate_avg_grade); ?>" style="margin-top:8px; margin-left: 5px;"></em></p>*/ ?>
            </div>
        </div>

        <div class="clearfix Userphoneall">
            <div class="fl Userphone"><?php echo e(str_replace(substr($demand->data->phone,3,4),'****',$demand->data->phone)); ?></div>
            <div class="fl Useradress"><?php echo e($demand->hideAddress()); ?></div>
            <p class="Userlook bgfff">报价被选定后才能查看</p>
        </div>

        <div class="clearfix evaluateall">
            <div class="fl evaluate">
                收到的评价
            </div>
            <a class="fr evaluateMore" href="<?php echo e(url('wechat/user/all-evaluate/issue/'.$user->id)); ?>">
                更多评价
            </a>
        </div>

        <ul class="evaluateUl ">
            <?php foreach($evaluate as $v): ?>
                <li class="clearfix">
                    <div class="evaluateUlimg">
                        <img src="<?php echo e(isset($v->evaluateUser->img_url) ? $v->evaluateUser->img_url : ''); ?>"/>
                    </div>
                    <div class="evaluateUlR">
                        <div class="clearfix evaluateUltit">
                            <div class="fl evaluateUltit1">
                                <span class="ellipsis1"><?php echo e(isset($v->evaluateUser->nickname) ? $v->evaluateUser->nickname : ''); ?></span>
                            </div>
                            <div class="fr evaluateUltit2">
                                <span class="ellipsis1"><?php echo e($v->create_time); ?></span>
                            </div>
                        </div>
                        <div class="evaluateUltit3 ellipsis1">
                            <?php echo e($v->content); ?>

                        </div>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>

        <p class="fabuing">正在发布</p>
        <ul class="fubuimgList clearfix">
            <?php foreach($demandList as $v): ?>
                <li>
                    <a href="<?php echo e(url('wechat/tender/demand-details/'.$v->id)); ?>">
                        <div class="timespan2" id="time<?php echo e($v->id); ?>">
                            <span class="day_show">0</span><em>天</em>
                            <span class="hour_show"><s id="h"></s>0</span><em>时</em>
                            <span class="minute_show"><s></s>0</span><em>分</em>
                            <span class="second_show"><s></s>0</span><em>秒</em>
                        </div>
                        <?php if($v->demandGoods&&$v->demandGoods->first()): ?>
                            <div class="fubuimgListimg">
                                <img src="<?php echo e(isset($v->demandGoods->first()->img->url) ? $v->demandGoods->first()->img->url : ''); ?>"/>
                            </div>
                            <div class="fubuimgListword1 ellipsis1"><?php echo e($v->demandGoods->first()->name); ?></div>
                            <p class="fubuimgListword2">￥<?php echo e($v->demandGoods->first()->price); ?></p>
                            <div class="clearfix ">
                                <div class="fubuimgListword3">
                                    <div class="ellipsis1 fubuimgListword3icon"><?php echo e($v->demandGoods->first()->getSite()); ?></div>
                                </div>
                                <div class="fubuimgListword4"><?php echo e($v->issue_time); ?></div>
                            </div>
                        <?php endif; ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        function timer(intDiff, obj) {//倒计时
            window.setInterval(function () {
                var day = 0,
                    hour = 0,
                    minute = 0,
                    second = 0;//时间默认值
                if (intDiff > 0) {
                    day = Math.floor(intDiff / (60 * 60 * 24));
                    hour = Math.floor(intDiff / (60 * 60)) - (day * 24);
                    minute = Math.floor(intDiff / 60) - (day * 24 * 60) - (hour * 60);
                    second = Math.floor(intDiff) - (day * 24 * 60 * 60) - (hour * 60 * 60) - (minute * 60);
                }
                if (minute <= 9) minute = '0' + minute;
                if (second <= 9) second = '0' + second;
                $(obj + ' .day_show').html(day);
                $(obj + ' .hour_show').html('<s id="h"></s>' + hour);
                $(obj + ' .minute_show').html('<s></s>' + minute);
                $(obj + ' .second_show').html('<s></s>' + second);
                intDiff--;
            }, 1000);
        }
        $(function () {
            //列表图片
            var fuW = $(".fubuimgListimg").width();
            $('.fubuimgListimg').css("height", fuW);

            <?php foreach($demandList as $v): ?>
            timer(parseInt(<?php echo e($v->end_time-time()); ?>), "#time<?php echo e($v->id); ?>");
            <?php endforeach; ?>
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>