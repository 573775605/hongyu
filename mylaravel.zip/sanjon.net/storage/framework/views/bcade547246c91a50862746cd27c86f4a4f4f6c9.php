<?php $__env->startSection('title','参加报价'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/wechat/css/AddSubtract.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="Uneedtit clearfix XQdingdan">
        <span class="Uword2">订单号:<?php echo e($demand->order_number); ?></span>
        <span class="Uorder">订单总额:<em class="Iprice">¥<?php echo e(number_format($demand->getPrice(),2)); ?></span>
        <span class="btnsqueryellow fr" onclick="location.href='<?php echo e(url('wechat/about/explain-article/hotboom_assure_deal')); ?>'">担保交易</span>
    </div>

    <div class=" XQcont">
        <?php foreach($demand->demandGoods as $v): ?>
            <div class="XQcontwords">
                <div class="clearfix">
                    <div class="fl orderLinkword">
                        <p class="Uneedcontwords1 ellipsis1"><?php echo e($v->name); ?></p>
                    </div>
                    <?php if($v->type=='link'): ?>
                        <?php if(in_array($v->domain,['tmall','taobao'])): ?>
                            <div class="fr" onclick="location.href='<?php echo e(url('wechat/check-browse?url='.urlencode($v->link))); ?>'">
                                <div class="btnsquerIcongreen">
                                    <input type="button" value="商品链接">
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="fr" onclick="location.href='<?php echo e($v->link); ?>'">
                                <div class="btnsquerIcongreen">
                                    <input type="button" value="商品链接">
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <div class="clearfix">
                    <div class="fl Uneedcontwords2"><em class="Uneedred1">¥<?php echo e($v->known_unit_price); ?></em> / *<?php echo e($v->count); ?><?php echo e($v->unit); ?></div>
                    <div class="fr Uneedcontwords3">货源： <em class="Uneedred1"><?php echo e($v->source); ?></em></div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <a class=" XQ2adress jiantou">
        <div class="clearfix XQ2adressword1">
            <div class="fl">
                收货人：<?php echo e($demand->consignee); ?>

            </div>
            <div class="fr">
                <?php echo e(str_replace(substr($demand->phone,3,4),'****',$demand->phone)); ?>

            </div>
        </div>
        <div class="XQ2adressword2 ellipsis2">
            收货地址：<?php echo e($address); ?>

        </div>
    </a>

    <form action="" method="post" id="form" onsubmit="return checkForm()">
        <?php echo csrf_field(); ?>

        <input type="hidden" name="demand_id" value="<?php echo e(request('demand_id')); ?>">
        <input type="hidden" name="type" value="<?php echo e(request('type')); ?>">
        <input type="hidden" name="hotboom_lng" value="<?php echo e(request('hotboom_lng')); ?>">
        <input type="hidden" name="hotboom_lat" value="<?php echo e(request('hotboom_lat')); ?>">
        <input type="hidden" name="hotboom_store_name" value="<?php echo e(request('hotboom_store_name')); ?>">
        <?php foreach(request('advantage',[]) as $k=>$v): ?>
            <?php if(isset($v['select'])): ?>
                <?php foreach($v['select'] as $v1): ?>
                    <input type="hidden" name="advantage[<?php echo e($k); ?>][select][]" value="<?php echo e($v1); ?>">
                <?php endforeach; ?>
            <?php endif; ?>
            <input type="hidden" name="advantage[<?php echo e($k); ?>][other]" value="<?php echo e($v['other']); ?>">
        <?php endforeach; ?>

        <?php /*<dl class="offers clearfix">*/ ?>
        <?php /*<dt class="mt12"><em>*</em>报价类型：</dt>*/ ?>
        <?php /*<dd>*/ ?>
        <?php /*<div class="border jiantoub">*/ ?>
        <?php /*<select name="hotboom_type" class="selects selectstext">*/ ?>
        <?php /*<?php foreach($hotboomType as $k=>$v): ?>*/ ?>
        <?php /*<option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>*/ ?>
        <?php /*<?php endforeach; ?>*/ ?>
        <?php /*</select>*/ ?>
        <?php /*</div>*/ ?>
        <?php /*</dd>*/ ?>
        <?php /*</dl>*/ ?>

        <dl class="offers clearfix">
            <dt class="mt12"><em>*</em>报价金额(元)：</dt>
            <dd>
                <div class="border Daddress">
                    <input type="number" placeholder="您代购该订单收取的总价款" name="quote" value="<?php echo e(request('quote')); ?>"/>
                </div>
            </dd>
        </dl>

        <dl class="offers clearfix">
            <dt class="mt12"><em>*</em>邮费：</dt>
            <dd>
                <div class="border Daddress">
                    <input type="number" placeholder="0" name="express_price" value="<?php echo e(request('express_price')); ?>"/>
                </div>
            </dd>
        </dl>
        <dl class="offers clearfix">
            <dt class="mt5"><em>*</em>报价优势：</dt>
            <dd>
                <a class="btnsqueryellow2">
                    <input type="button" value="选择" onclick="selectAdvantage()"/>
                </a>
            </dd>
        </dl>
        <dl class="offers clearfix">
            <dt class="mt5">库存数量：</dt>
            <dd>
                <div class="NBnumall clearfix ">
                    <span class="reduce"></span>
                    <input class="NBnumtext quantity" type="number" name="repertory" value="<?php echo e(request('repertory',1)); ?>">
                    <span class="plus"></span>
                </div>
            </dd>
        </dl>

        <dl class="offers clearfix">
            <dt class="mt5">代购有效期：</dt>
            <dd>
                <div class="NBnumall clearfix  ">
                    <span class="reduce"></span>
                    <input class="NBnumtext quantity" type="number" name="day" value="<?php echo e(request('day',1)); ?>">
                    <span class="timedate mr10">天</span>
                    <span class="plus"></span>
                </div>
                <div class="NBnumall clearfix mt15 ">
                    <span class="reduce"></span>
                    <input class="NBnumtext quantity" type="number" name="hour" value="<?php echo e(request('hour',1)); ?>">
                    <span class="timedate mr10">时</span>
                    <span class="plus"></span>
                </div>
            </dd>
        </dl>
    </form>

    <a class="redbtn90">
        <input type="button" value="确认报价" onclick="submitQuote()"/>
    </a>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        //选择报价优势
        function selectAdvantage() {
            var url = '<?php echo e(url('wechat/tender/select-advantage')); ?>'
            $('#form').attr('action', url);
            $('#form').submit();
        }
        //提交报价
        function submitQuote() {
            var url = '<?php echo e(url('wechat/tender/submit')); ?>'
            $('#form').attr('action', url);
            if ($('input[name=quote]').val() == '') {
                alert('请输入报价金额');
                return false;
            }
            $('#form').submit();
        }

        function changeCount(obj, count, defaultVal) { //改变数量
            var nowCount = $(obj).find('.quantity').val();
            nowCount = parseInt(nowCount);
            if (nowCount + count > 0) {
                $(obj).find('.quantity').val(nowCount + count);
            } else {
                $(obj).find('.quantity').val(defaultVal);
            }
        }
        $('.plus').click(function () {//加
            var divObj = $(this).parent('.NBnumall');
            changeCount(divObj, 1, 1);
        })
        $('.reduce').click(function () {//减
            var divObj = $(this).parent('.NBnumall');
            if ($(divObj).find('.quantity').attr('name') == 'day') {
                changeCount(divObj, -1, 0);
            } else {
                changeCount(divObj, -1, 1);
            }
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>