<?php foreach($rows as $v): ?>
    <li>
        <div class="Uneedtit clearfix">
            <span class="Uword2">订单号:<?php echo e(isset($v->demand->order_number) ? $v->demand->order_number : ''); ?></span>
            <span class="Uorder">订单总额:<em class="Iprice">¥<em class="Iprice2"><?php echo e($v->demand->getPrice()); ?></em></em></span>
            <span class="Idistance"><?php echo e(isset($v->demand->create_time) ? $v->demand->create_time : ''); ?></span>
        </div>

        <div class="Uneedcont clearfix" onclick="location.href='<?php echo e(url('wechat/tender/demand-details/'.$v->demand_id.'?tender_id='.$v->id)); ?>'">
            <div class="Uneedcontimg ">
                <img src="<?php echo e(isset($v->demand->demandGoods->first()->img->url) ? $v->demand->demandGoods->first()->img->url : ''); ?>">
            </div>
            <div class="fl Uneedcontwords">
                <p class="Uneedcontwords1 ellipsis1"><?php echo e(isset($v->demand->demandGoods->first()->name) ? $v->demand->demandGoods->first()->name : ''); ?></p>
                <p class="Uneedcontwords2">
                    <em class="Uneedred1">¥<span class="Uneedred2"><?php echo e(isset($v->demand->demandGoods->first()->known_unit_price) ? $v->demand->demandGoods->first()->known_unit_price : ''); ?></span></em> /
                    *<?php echo e(isset($v->demand->demandGoods->first()->count) ? $v->demand->demandGoods->first()->count : ''); ?><?php echo e($v->demand->demandGoods->first()->unit); ?></p>
                <p class="Uneedcontwords3 clearfix"><span class="fl"><?php echo e($v->demand->getIssueSite()); ?></span></p>
            </div>
        </div>

        <div class="clearfix Uneedtime">
            <div class="Orderwgreen fl ">参与报价</div>
            <?php if($v->status==1): ?>
                <div class="timespan fl" id="time<?php echo e($v->id); ?>">
                    <span class="day_show">0</span>&nbsp;<em>天</em>
                    <span class="hour_show"><s id="h"></s>0</span>&nbsp;<em>时</em>
                    <span class="minute_show"><s></s>0</span>&nbsp;<em>分</em>
                    <span class="second_show"><s></s>0</span>&nbsp;<em>秒</em>
                </div>
                <script>
                    timer(parseInt(<?php echo e($v->demand->end_time-time()); ?>), "#time<?php echo e($v->id); ?>");
                </script>
            <?php endif; ?>
            <?php if($v->status==1|$v->status==3): ?>
                <div class="orderButtongreen fr mt5   ">
                    <input type="button" value="<?php echo e(isset($demandStatus[$v->demand->status]) ? $demandStatus[$v->demand->status] : ''); ?>">
                </div>
            <?php endif; ?>
            <?php if($v->isDelete()): ?>
                <a class="orderButtongred fr mt5" href="javascript:removeTender('<?php echo e(route('tenderDelete',['id'=>$v->id])); ?>')">
                    <input type="button" value="删除">
                </a>
            <?php endif; ?>

        </div>

    </li>
<?php endforeach; ?>