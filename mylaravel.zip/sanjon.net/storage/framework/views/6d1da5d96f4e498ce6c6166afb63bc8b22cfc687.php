<?php foreach($rows as $v): ?>
    <li>
        <div class="Uneedtit clearfix">
            <span class="Uword2">订单号:
                <input type="text" readonly="text" value="<?php echo e($v->order_number); ?>">
            </span>
            <span class="Uorder">订单总额:<em class="Iprice">¥<?php echo e($v->known_price); ?></em></span>
            <span class="Idistance"><?php echo e($v->create_time); ?></span>
        </div>
        <?php if($v->demandGoods && $v->demandGoods->first()): ?>
            <a href="<?php echo e(url('wechat/demand/details/'.$v->id)); ?>">
                <div class="Uneedcont clearfix">
                    <div class="Uneedcontimg ">
                        <img src="<?php echo e(isset($v->demandGoods->first()->img->url) ? $v->demandGoods->first()->img->url : ''); ?>">
                    </div>
                    <div class="fl Uneedcontwords">
                        <p class="Uneedcontwords1 ellipsis1"><?php echo e($v->demandGoods->first()->name); ?></p>
                        <p class="Uneedcontwords2"><em class="Uneedred1">¥<?php echo e($v->demandGoods->first()->known_unit_price); ?></em> /
                            *<?php echo e($v->demandGoods->first()->count); ?><?php echo e($v->demandGoods->first()->unit); ?></p>
                        <p class="Uneedcontwords3 clearfix"><span class="fl"><?php echo e($v->getIssueSite()); ?></span></p>
                    </div>
                </div>
            </a>
        <?php endif; ?>
        <div class="clearfix Uneedtime">
            <div class="ordertimeL clearfix">
            <div class="Orderwyellow fl ">
                <?php if($v->is_select): ?>
                    已选中报价
                <?php else: ?>
                    已有<?php echo e($v->userTender->whereLoose('status',1)->count()); ?>人报价
                <?php endif; ?>
            </div>
            <?php if($v->status==1||$v->status==2): ?>
                <div class="timespan" id="time<?php echo e(request('status')); ?><?php echo e($v->id); ?>">
                    <?php if($v->status==1): ?>
                        <span class="day_show">0</span>&nbsp;<em>天</em>
                    <?php endif; ?>
                    <span class="hour_show"><s id="h"></s>0</span>&nbsp;<em>时</em>
                    <span class="minute_show"><s></s>0</span>&nbsp;<em>分</em>
                    <span class="second_show"><s></s>0</span>&nbsp;<em>秒</em>
                </div>
                <script>
                    <?php if($v->is_select): ?>
                    timer(<?php echo e($v->pay_end_time-time()); ?>, '#time<?php echo e(request('status')); ?><?php echo e($v->id); ?>');
                    <?php else: ?>
                    timer(<?php echo e($v->end_time-time()); ?>, '#time<?php echo e(request('status')); ?><?php echo e($v->id); ?>');
                    <?php endif; ?>
                </script>
            <?php endif; ?>
            </div>
            <div class="orderButtonyellow mt5   ">
                <?php if($v->status==-2): ?>
                    <input type="button" value="<?php echo e($status[$v->status].'('.$returnStatus[$v->returnGoodsApply->status].')'); ?>">
                <?php elseif($v->status!=5): ?>
                    <input type="button" value="<?php echo e(isset($status[$v->status]) ? $status[$v->status] : ''); ?>">
                <?php else: ?>
                    <input type="button" value="<?php echo e($v->issue_evaluate?'已完成':'待评价'); ?>">
                <?php endif; ?>
            </div>
        </div>
    </li>
<?php endforeach; ?>