<?php if(isset($menu['url'])): ?>
    <li>
        <a class="J_menuItem" href="<?php echo e(url($menu['url'])); ?>">
            <i class="<?php echo e(isset($menu['icon']) ? $menu['icon'] : 'fa fa-leaf'); ?>"></i>
            <span class="nav-label"><?php echo e($menu['title']); ?></span>
        </a>
    </li>
<?php else: ?>
    <li>
        <a href="#">
            <i class="<?php echo e(isset($menu['icon']) ? $menu['icon'] : 'fa fa-plus-square-o'); ?>"></i>
            <span class="nav-label"><?php echo e($menu['title']); ?></span><span class="fa arrow"></span>
        </a>
        <ul class="nav nav-second-level">
            <?php echo $child; ?>

        </ul>
    </li>
<?php endif; ?>
