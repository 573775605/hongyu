<?php $__env->startSection('title','消息中心'); ?>


<?php $__env->startSection('content'); ?>

             <ul class="Mynews " >
                <li class="mynewsicon1">

                    <a href="<?php echo e(url('wechat/chat/index')); ?>" class="jiantou">聊天消息 </a>
                        <?php if($chatMessageCount): ?>
                            <span class="mynewqipao"><?php echo e($chatMessageCount); ?></span>
                        <?php endif; ?>

                </li>
                <li class="mynewsicon2">

                    <a href="<?php echo e(url('wechat/message/content/tender')); ?>" class="jiantou">报价消息 </a>
                        <?php if($tenderMessageCount): ?>
                            <span class="mynewqipao"><?php echo e($tenderMessageCount); ?></span>
                        <?php endif; ?>

                </li>
                <li class="mynewsicon3">
                    <a href="<?php echo e(url('wechat/message/content/demand')); ?>" class="jiantou">订单消息 </a>
                        <?php if($demandMessageCount): ?>
                            <span class="mynewqipao"><?php echo e($demandMessageCount); ?></span>
                        <?php endif; ?>

                </li>
                <li class="mynewsicon4">

                    <a href="<?php echo e(url('wechat/message/content/system')); ?>" class="jiantou">系统消息</a>
                    <?php if($systemMessageCount): ?>
                        <span class="mynewqipao"><?php echo e($systemMessageCount); ?></span>
                    <?php endif; ?>
                </li>
                <li class="mynewsicon5">

                    <a href="<?php echo e(url('wechat/message/content/other')); ?>" class="jiantou">其他消息 </a>
                        <?php if($otherMessageCount): ?>
                            <span class="mynewqipao"><?php echo e($otherMessageCount); ?></span>
                        <?php endif; ?>

                </li>
</ul>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>




    <script>
        $(function () {
            if ($(".mynewqipao").text().length > 3) {
                $(".mynewqipao").html("...");
                $(".mynewqipao").css({"height": "26px", "line-height": "10px", "font-size": "26px"});
            }
        })
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>