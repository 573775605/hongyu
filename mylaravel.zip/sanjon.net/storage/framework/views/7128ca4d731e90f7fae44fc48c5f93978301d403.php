<?php foreach($evaluate as $v): ?>
    <li>
        <p class="MlevelListword1"><?php echo e($v->create_time); ?></p>
        <div class="MlevelListword2">
            <dl class="MXdlall borderB clearfix">
                <dt>订单号：</dt>
                <dd><?php echo e(isset($v->demand->order_number) ? $v->demand->order_number : ''); ?></dd>
            </dl>

            <dl class="MXdlall clearfix">
                <dt>购买商品获得：</dt>
                <?php if(request('type')=='issue'): ?>
                    <dd><span class="Mlevelgreen">+ <?php echo e($v->grade); ?></span></dd>
                <?php else: ?>
                    <dd><span class="Mlevelgreen">+ <?php echo e($v->avg_grade); ?></span></dd>
                <?php endif; ?>
            </dl>
        </div>
    </li>
<?php endforeach; ?>