<?php $__env->startSection('title','发布成功'); ?>

<?php $__env->startSection('content'); ?>
    <div class="SuccessAll"></div>
    <p class="SuccessAllword1">恭喜您发布成功，等待报价！</p>
    <p class="SuccessAllword2">报价结果将以系统消息通知！</p>


    <a class="whitebtn80" href="<?php echo e(url('wechat/address')); ?>?is_issue=1">
        <input type="button" name="" id="" value="继续发布"/>
    </a>

    <a class="redbtn80 " href="<?php echo e(url('wechat/demand/index')); ?>">
        <input type="button" name="" id="" value="查看"/>
    </a>

    <a class="yellowbtn80 " href="<?php echo e(url('wechat')); ?>">
        <input type="button" name="" id="" value="首页"/>
    </a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>