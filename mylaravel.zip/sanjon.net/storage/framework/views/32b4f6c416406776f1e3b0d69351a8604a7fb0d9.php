<?php $__env->startSection('title','收货地址列表'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/wechat/css/adress.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body','bgf6'); ?>

<?php $__env->startSection('content'); ?>
    <ul class=" adresswrite ">
        <?php if(request('type')=='issue-demand'): ?>
            <?php foreach($rows as $v): ?>
                <li class="checkhid1 <?php echo e($v->is_default?'jiantour':''); ?>" onclick="location.href='<?php echo e(url('wechat/issue/index?action=type&address_id='.$v->id)); ?>'">
                    <p class="clearfix f15c1f "><span class="fl">收货人：<?php echo e($v->name); ?></span><span class="fr"><?php echo e($v->phone); ?></span></p>
                    <p class="ellipsisTwo f12c64 mtb5 addMO">
                        <?php echo $v->is_default?'<em class="Mo">[默认]</em>':''; ?>收货地址：<?php echo e($v->province.$v->city.$v->area.$v->address); ?>

                    </p>
                </li>
            <?php endforeach; ?>
        <?php elseif(request('type')=='copy-demand'): ?>
            <?php foreach($rows as $v): ?>
                <li class="checkhid1 <?php echo e($v->is_default?'jiantour':''); ?>" onclick="location.href='<?php echo e(url('wechat/demand/copy-demand?address_id='.$v->id)); ?>'">
                    <p class="clearfix f15c1f "><span class="fl">收货人：<?php echo e($v->name); ?></span><span class="fr"><?php echo e($v->phone); ?></span></p>
                    <p class="ellipsisTwo f12c64 mtb5 addMO">
                        <?php echo $v->is_default?'<em class="Mo">[默认]</em>':''; ?>收货地址：<?php echo e($v->province.$v->city.$v->area.$v->address); ?>

                    </p>
                </li>
            <?php endforeach; ?>
        <?php else: ?>
            <?php foreach($rows as $v): ?>
                <li class="checkhid1">
                    <p class="clearfix f15c1f "><span class="fl">收货人：<?php echo e($v->name); ?></span><span class="fr"><?php echo e($v->phone); ?></span></p>
                    <p class="ellipsisTwo f12c64 mtb5 addMO">
                        <?php echo $v->is_default?'<em class="Mo">[默认]</em>':''; ?>收货地址：<?php echo e($v->province.$v->city.$v->area.$v->address); ?>

                    </p>
                    <div class="clearfix bianji">
                        <a class="fr" href="<?php echo e(url('wechat/address/edit/'.$v->id)); ?>">
                            <em class="write">编辑</em>
                        </a>
                        <span class="fr"><em class="del" onclick="removeAddress(<?php echo e($v->id); ?>)">删除</em></span>
                        <?php if(!$v->is_default): ?>
                            <span class="fr setMo" onclick="setDefault(<?php echo e($v->id); ?>)">设为默认</span>
                        <?php endif; ?>
                    </div>
                </li>
            <?php endforeach; ?>
        <?php endif; ?>
    </ul>

    <div class="addAdress" onclick="location.href='<?php echo e(url('wechat/address/add?type='.request('type'))); ?>'">
        <input type="button" value="新增收件人地址"/>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('asset/ext/layer/layer.min.js')); ?>"></script>
    <script type="text/javascript">
        function setDefault(id) {
            $.post("<?php echo e(url('wechat/address/set-default')); ?>/" + id,
                {_token: '<?php echo e(csrf_token()); ?>'},
                function (data, status) {
                    if (data.status != 1) {
                        layer.msg(data.message);
                    } else {
                        location.reload();
                    }
                });
        }

        function removeAddress(id) {
            if (confirm('你确定要删除吗？')) {
                $.post("<?php echo e(url('wechat/address/remove')); ?>/" + id,
                    {_token: '<?php echo e(csrf_token()); ?>'},
                    function (data, status) {
                        if (data.status != 1) {
                            layer.msg(data.message);
                        } else {
                            location.reload();
                        }
                    });
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>