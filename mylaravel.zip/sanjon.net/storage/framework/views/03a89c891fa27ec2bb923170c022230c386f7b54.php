<?php $__env->startSection('title','选择报价优势'); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .hotboom-radio {
            display: none;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(request('tender_id')?url('wechat/tender/edit/'.request('tender_id')):url('wechat/tender/index')); ?>" method="post" id="form">
        <?php echo csrf_field(); ?>

        <input type="hidden" name="select_type" value="other_store">
        <?php foreach(request()->input() as $k=>$v): ?>
            <?php if($k!='advantage'): ?>
                <input type="hidden" name="<?php echo e($k); ?>" value="<?php echo e($v); ?>">
            <?php endif; ?>
        <?php endforeach; ?>
        <p class="Badvantagetit">
            货品来源 <em>（二选一）</em>
        </p>
        <div class="p3">
            <div class="laiyuan clearfix mb10">
                <?php if(request('type')): ?>
                    <label class="laiyuanL <?php echo e(request('type')=='raw-hotboom'?'active':''); ?>">
                        <input class="hotboom-radio" type="radio" name="type" value="raw-hotboom" <?php echo e(request('type')=='raw-hotboom'?'checked':''); ?>>
                        原路代购
                    </label>
                    <label class="laiyuanR <?php echo e(request('type')=='other-hotboom'?'active':''); ?>">
                        <input class="hotboom-radio" type="radio" name="type" value="other-hotboom" <?php echo e(request('type')=='other-hotboom'?'checked':''); ?>>
                        其他店铺
                    </label>
                <?php elseif(isset($tender)): ?>
                    <label class="laiyuanL <?php echo e($tender->type=='raw-hotboom'?'active':''); ?>">
                        <input class="hotboom-radio" type="radio" name="type" value="raw-hotboom" <?php echo e($tender->type=='raw-hotboom'?'checked':''); ?>>
                        原路代购
                    </label>
                    <label class="laiyuanR <?php echo e($tender->type=='other-hotboom'?'active':''); ?>">
                        <input class="hotboom-radio" type="radio" name="type" value="other-hotboom" <?php echo e($tender->type=='other-hotboom'?'checked':''); ?>>
                        其他店铺
                    </label>
                <?php else: ?>
                    <label class="laiyuanL active">
                        <input class="hotboom-radio" type="radio" name="type" value="raw-hotboom" checked>
                        原路代购
                    </label>
                    <label class="laiyuanR">
                        <input class="hotboom-radio" type="radio" name="type" value="other-hotboom">
                        其他店铺
                    </label>
                <?php endif; ?>
            </div>
        </div>
        <div class="LYcont">
            <div class="LYconts"></div>
            <div class="LYconts">
                <div class="p3">
                    <div class="border mb10">
                        <input class="inputfz" type="text" name="hotboom_store_name" value="<?php echo e(request('hotboom_store_name')); ?>" placeholder="粘贴其他店铺链接或填写实体店铺名称"/>
                    </div>
                    <div class="XQadress jiantou border" onclick="selectSite()">
                        实体店定位
                    </div>
                </div>
            </div>
            <?php foreach($rows as $v): ?>
                <p class="Badvantagetit">
                    <?php echo e($v->name); ?> <em>（可多选）</em>
                </p>
                <div class="p3">
                    <div class="box clearfix">
                        <?php foreach(json_decode($v->label) as $v1): ?>
                            <span class="checkbox_item checkbox_itemW">
                            <?php if(request('tender_id')): ?>
                                    <label class="check_label <?php echo e(in_array($v1,$label)?'checked on':''); ?>">
            <input type="checkbox" name="advantage[<?php echo e($v->name); ?>][select][]" value="<?php echo e($v1); ?>" <?php echo e(in_array($v1,$label)?'checked':''); ?>/>
                <em class="checkbox_text"><?php echo e($v1); ?></em>
            </label>
                                <?php else: ?>
                                    <label class="check_label">
            <input type="checkbox" name="advantage[<?php echo e($v->name); ?>][select][]" value="<?php echo e($v1); ?>"/>
                <em class="checkbox_text"><?php echo e($v1); ?></em>
            </label>
                                <?php endif; ?>
                        </span>
                        <?php endforeach; ?>
                    </div>

                    <div class="border">
                        <input class="inputfz" type="text" name="advantage[<?php echo e($v->name); ?>][other]" placeholder="其他"/>
                    </div>
                </div>
            <?php endforeach; ?>

            <div class="redbtn90">
                <input type="submit" value="确认"/>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mui-js'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        function selectSite() {
            var url = '<?php echo e(url('wechat/issue/select-site')); ?>';
            $('#form').attr('action', url);
            $('#form').submit();
        }

        $(function () {
            $(".checkbox_text").click(function () {
                if ($(this).parent().hasClass('on')) {
                    $(this).parent().removeClass('on');
                } else {
                    $(this).parent().addClass('on');
                }
            });
            //选择购买商家位置
            $('#select-site').click(function () {
                var url = '<?php echo e(url('wechat/tender/select-store-site?tender_id='.request('tender_id'))); ?>';
                $('#form').attr('action', url);
                $('#form').submit();
            });

            $(".laiyuan label").click(function () {
                var i = $(".laiyuan label").index($(this));
                $(".laiyuan label").removeClass("active");
                $(this).addClass("active");
                $(".LYcont .LYconts").removeClass('active')
                $(".LYcont .LYconts").eq(i).addClass("active");
            })
            $(".LYcont .LYconts").eq($('.laiyuan input').index($('.hotboom-radio:checked'))).addClass("active");

        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>