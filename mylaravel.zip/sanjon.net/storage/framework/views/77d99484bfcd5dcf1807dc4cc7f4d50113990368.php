<?php $__env->startSection('title','聊天消息'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/ext/dropload/dropload.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body','bgfff'); ?>
<?php $__env->startSection('content'); ?>
    <div id="dropload">
        <div style="padding: 3% 5%;" id="message">
            <?php foreach($message->sortBy('id') as $v): ?>
                <?php if($user->id==$v->send_user_id): ?>
                    <div class="chatall">
                        <div class="clearfix chartcont">
                            <div class="touxiangimgR">
                                <img src="<?php echo e(isset($v->sendUser->img_url) ? $v->sendUser->img_url : ''); ?>"/>
                            </div>
                            <div class="fr chartmine">
                                <?php if(filter_var($v->content,FILTER_VALIDATE_URL)): ?>
                                    <a href="<?php echo e($v->content); ?>"><?php echo e($v->content); ?></a>
                                <?php else: ?>
                                    <input type="text" readonly="readonly" value="<?php echo e($v->content); ?>">
                                <?php endif; ?>

                                <?php if($v->img): ?>
                                    <img src="<?php echo e($v->img->url); ?>"/>
                                <?php endif; ?>
                            </div>
                        </div>
                        <p class="fr chartMtimeR"><?php echo e($v->create_time); ?></p>
                    </div>
                <?php else: ?>
                    <div class="chatall">
                        <div class="clearfix chartcont">
                            <div class="touxiangimgL">
                                <img src="<?php echo e(isset($v->sendUser->img_url) ? $v->sendUser->img_url : ''); ?>"/>
                            </div>
                            <div class="fl chartother">
                                <?php if(filter_var($v->content,FILTER_VALIDATE_URL)): ?>
                                    <a href="<?php echo e($v->content); ?>"><?php echo e($v->content); ?></a>
                                <?php else: ?>
                                    <input type="text" readonly="readonly" value="<?php echo e($v->content); ?>">
                                <?php endif; ?>
                                <?php if($v->img): ?>
                                    <img src="<?php echo e($v->img->url); ?>"/>
                                <?php endif; ?>
                            </div>
                        </div>
                        <p class="fl chartMtimeL"><?php echo e($v->create_time); ?></p>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    </div>

    <div style="height:55px"></div>
    <form action="" id="form" onsubmit="return submitMessage()">
        <input type="hidden" name="accept_user_id" value="<?php echo e($acceptUserId); ?>">
        <input type="hidden" name="img_id">
        <div class="chartinput">
            <div class="chartinputss clearfix">
                <input type="text" placeholder="我来说两句" name="content"/>
                <input type="file" name="file" id="file" style="display: none">
            </div>
            <div class="send"><input type="button" value="发送" onclick="submitMessage()"/></div>
            <div class="chartimg" onclick="$('#file').trigger('click')"></div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('asset/ext/layer/layer.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/ext/dropload/dropload.min.js')); ?>"></script>
    <?php /*上传插件*/ ?>
    <script src="<?php echo e(asset("asset/ext/jquery-file-upload/vendor/jquery.ui.widget.js")); ?>"></script>
    <script src="<?php echo e(asset("asset/ext/jquery-file-upload/jquery.iframe-transport.js")); ?>"></script>
    <script src="<?php echo e(asset("asset/ext/jquery-file-upload/jquery.fileupload.js")); ?>"></script>
    <script>
        function submitMessage() {
            if ($('input[name=content]').val() == '' && $('input[name=img_id]').val() == '') {
                layer.msg('请输入聊天内容');
                return false;
            }
            $.post("<?php echo e(url('wechat/chat/send')); ?>",
                $('#form').serialize(),
                function (data, status) {
                    if (data.status != 1) {
                        layer.msg('发送失败');
                    } else {
                        $('#message').append(data.data.html);
                        $('input[name=content]').val('');
                        $('input[name=img_id]').val('');
                        maxId = data.data.result.id;
                    }
                });
            return false
        }

        var maxId = <?php echo e(isset($message->first()->id) ? $message->first()->id : 0); ?>

        setInterval(function () {
            $.post("<?php echo e(url('wechat/chat/pull')); ?>",
                {max_id: maxId, accept_user_id: '<?php echo e($acceptUserId); ?>'},
                function (data, status) {
                    $('#message').append(data.data.message);
                    maxId = data.data.maxId;
                }
            )
            ;
        }, 5000);

        var page = 2, pageTotal =<?php echo e($message->lastPage()); ?>;
        $('#dropload').dropload({
            scrollArea: window,
            autoload: false,
            domUp: {
                domClass: 'dropload-up',
                domRefresh: '<div class="dropload-refresh"><span>下拉刷新</span></div>',
                domUpdate: '<div class="dropload-update"><span>释放更新</span></div>',
                domLoad: '<div class="dropload-load">加载中</div>'
            },
            loadUpFn: function (me) {
                $.post("<?php echo e(url('wechat/chat/paging')); ?>",
                    {max_id: maxId, accept_user_id: '<?php echo e($acceptUserId); ?>', page: page},
                    function (data, status) {
                        $('#message').prepend(data.data.message);
                        page++;
                        if (page > pageTotal) {
                            // 锁定
                            me.lock();
                            // 无数据
//                            me.noData();
                        }
                        me.resetload();
                    });
            }
        });

        $('#file').fileupload({
            url: '<?php echo e(url('wechat/upload')); ?>',
            formData: {_token: '<?php echo e(csrf_token()); ?>'},
            //dataType: 'json',
            done: function (e, data) {
                $('input[name=img_id]').val(data.result.data.id);
                submitMessage();
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>