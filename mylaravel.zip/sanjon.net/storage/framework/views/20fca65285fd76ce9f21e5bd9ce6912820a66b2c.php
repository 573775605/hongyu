<?php $__env->startSection('title','余额提现'); ?>

<?php $__env->startSection('content'); ?>
    <dl class="dlinput clearfix">
        <dt class="fl">提现到：</dt>
        <dd class="fl">
            <div class="dlinputtext  jiantoub">
                <select name="" class="selects" onchange="selectFund(this)">
                    <?php if($alipay): ?>
                        <option value="alipay">支付宝</option>
                    <?php endif; ?>
                    <?php foreach($bank as $v): ?>
                        <option value="<?php echo e($v->id); ?>"><?php echo e($v->bank_name.'(尾号'.substr($v->account,-4).')'); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </dd>
    </dl>
    <form action="" method="post" onsubmit="return submitCheck()" id="form">
        <?php echo csrf_field(); ?>

        <input type="hidden" name="type" value="<?php echo e(request('type')); ?>">
        <div id="withdraw-fund">
            <?php if($alipay || !$bank->count()): ?>
                <dl class="dlword clearfix">
                    <dt class="fl"> 支付宝账号：</dt>
                    <input type="hidden" name="fund_id" value="<?php echo e(isset($alipay->id) ? $alipay->id : ''); ?>">
                    <dd class="fl">
                        <?php /*<span class="dlbuleword">*/ ?>
                        <?php echo e(isset($alipay->account) ? $alipay->account : ''); ?>

                        <?php if(!$alipay): ?>
                            <?php /*<a class="redbtn90" href="<?php echo e(url('wechat/wallet/alipay-account?type='.request('type'))); ?>"><input type="button" value="添加支付宝"/></a>*/ ?>
                            <a class="addpay" href="<?php echo e(url('wechat/wallet/alipay-account?type='.request('type'))); ?>"><input type="button" value="添加支付宝"/></a>

                        <?php endif; ?>
                        <?php /*</span>*/ ?>
                    </dd>
                </dl>
            <?php else: ?>
                <dl class="dlword clearfix">
                    <dt class="fl"> 银行卡号：</dt>
                    <input type="hidden" name="fund_id" value="<?php echo e(isset($bank->first()->id) ? $bank->first()->id : ''); ?>">
                    <dd class="fl">
                    <span class="dlbuleword">
                        <?php echo e(isset($bank->first()->account) ? $bank->first()->account : ''); ?>

                    </span>
                    </dd>
                </dl>
            <?php endif; ?>
        </div>
        <dl class="dlinput clearfix">
            <dt class="fl"> 提现金额：</dt>
            <dd class="fl">
                <div class="dlinputtext">
                    <input type="number" placeholder="请输入金额" name="price"/>
                </div>
                <div class="clearfix mt10">
                    <?php if(request('type')=='pledge'): ?>
                        <div class="fl"><span class="dl9wrod">可提现金额:</span>
                            <em class="dlredwrod">¥<?php echo e($user->getPledge()); ?></em>
                        </div>
                    <?php else: ?>
                        <div class="fl"><span class="dl9wrod">可提现余额:</span>
                            <em class="dlredwrod">¥<?php echo e(request('type')=='hotboom'?$user->getDaigouBalance():$user->getBalance()); ?></em>
                        </div>
                        <?php if(request('type')=='hotboom'): ?>
                            <div class="fr dlquestionicoin"><span class="dld6wrod">平台服务费: <?php echo e($scale); ?>%</span></div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </dd>
        </dl>
    </form>
    <a class="redbtn90">
        <input type="button" value="提交" onclick="submitWithdraw()"/>
    </a>
    <div style="display: none">
        <?php if($alipay): ?>
            <div id="alipay-account">
                <dl class="dlword clearfix">
                    <dt class="fl"> 支付宝账号：</dt>
                    <input type="hidden" name="fund_id" value="<?php echo e(isset($alipay->id) ? $alipay->id : ''); ?>">
                    <dd class="fl">
                    <span class="dlbuleword">
                        <?php echo e(isset($alipay->account) ? $alipay->account : ''); ?>

                    </span>
                    </dd>
                </dl>
            </div>
        <?php endif; ?>
        <?php foreach($bank as $v): ?>
            <div id="bank-account<?php echo e($v->id); ?>">
                <dl class="dlword clearfix">
                    <dt class="fl"> 银行卡号：</dt>
                    <input type="hidden" name="fund_id" value="<?php echo e($v->id); ?>">
                    <dd class="fl">
                    <span class="dlbuleword">
                        <?php echo e($v->account); ?>

                    </span>
                    </dd>
                </dl>
            </div>
        <?php endforeach; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('asset/ext/layer/layer.min.js')); ?>"></script>
    <script>
        function selectFund(event) {
            var val = $(event).val();
            if (val == 'alipay') {
                $('#withdraw-fund').html($('#alipay-account').html())
            } else {
                $('#withdraw-fund').html($('#bank-account' + val).html());
            }
        }

        var layerConfirm = false;
        function submitCheck() {
                    <?php if(request('type')=='pledge'): ?>
            var balance =<?php echo e($user->getPledge()); ?>;
                    <?php else: ?>
            var balance =<?php echo e(request('type')=='hotboom'?$user->getDaigouBalance():$user->getBalance()); ?>;
                    <?php endif; ?>
            var price = $('input[name=price]').val();
            price = parseFloat(price);
            if ($('input[name=fund_id]').val() == '') {
                layer.msg('请选择提现账户')
                return false;
            }
            if (isNaN(price)) {
                layer.msg('请输入有效提现金额');
                return false;
            }
            if (price < 10) {
                layer.msg('提现金额最少为10元');
                return false;
            }
            if (price > balance) {
                layer.msg('账户余额不足');
                return false;
            }
                    <?php if(request('type')=='hotboom'): ?>
            var scale =<?php echo e($scale/100); ?>;
            if (layerConfirm) {
                return true;
            }
            var servicePrice = price * scale;
            var actualPrice = price - servicePrice.toFixed(2);
            layer.confirm('提现金额' + price + ',其中平台服务费' + servicePrice.toFixed(2) + '，实际提现' + actualPrice.toFixed(2), {
                title: '平台服务费',
                btn: ['确认', '取消'], //按钮
//                shade: false //不显示遮罩
            }, function () {
                layerConfirm = true;
//                $('#form').submit();
                submitWithdraw();
            }, function () {

            });
            return false;
            <?php else: ?>
                return true;
            <?php endif; ?>
        }

        function submitWithdraw() {
            if (!submitCheck()) {
                return false;
            }

            $.post("<?php echo e(url('wechat/wallet/withdraw')); ?>",
                $('#form').serialize(),
                function (data, status) {
                    if (data.status != 1) {
                        layer.msg(data.message);
                    } else {
                        layer.msg('您的提现申请已提交，等待管理员审核');
                        setTimeout(function () {
                            location.reload()
                        }, 4000)
                    }
                });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>