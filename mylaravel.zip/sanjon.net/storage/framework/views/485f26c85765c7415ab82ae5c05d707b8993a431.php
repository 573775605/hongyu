<?php $__env->startSection('title','订单详情'); ?>

<?php $__env->startSection('content'); ?>
    <div class="ibox-content">
        <div class="row">
            <div class="col-sm-12">
                <div class="m-b-md">
                    <a href="javascript:history.go(-1)" class="btn btn-primary pull-right" style="width: 80px;height: 100%;margin-bottom: 0px;">返回</a>
                    <h2>订单详情</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-5">
                <dl class="dl-horizontal">

                    <dt>订单编号：</dt>
                    <dd><?php echo e($demand->order_number); ?></dd>
                    <div class="hr-line-dashed"></div>

                    <dt>创建时间：</dt>
                    <dd><?php echo e($demand->create_time); ?></dd>
                    <div class="hr-line-dashed"></div>

                    <dt>发布金额：</dt>
                    <dd><?php echo e($demand->known_price); ?></dd>
                    <div class="hr-line-dashed"></div>

                    <dt>报价金额：</dt>
                    <dd><?php echo e($demand->tender_price); ?>(<?php echo e($demand->express_price?'含邮费'.$demand->express_price:'免邮费'); ?>)</dd>
                    <div class="hr-line-dashed"></div>

                    <dt>优惠金额：</dt>
                    <dd><?php echo e($demand->coupon_price); ?></dd>
                    <div class="hr-line-dashed"></div>

                    <dt>实际支付：</dt>
                    <dd><?php echo e($demand->price); ?></dd>
                    <div class="hr-line-dashed"></div>

                    <dt>优惠金额：</dt>
                    <dd><?php echo e($demand->coupon_price); ?></dd>
                    <div class="hr-line-dashed"></div>

                    <dt>物流公司：</dt>
                    <dd><?php echo e(isset($express[$demand->express_company_number]) ? $express[$demand->express_company_number] : ''); ?></dd>
                    <div class="hr-line-dashed"></div>

                    <dt>物流单号：</dt>
                    <dd><?php echo e($demand->express_number); ?></dd>
                    <div class="hr-line-dashed"></div>

                    <dt>订单状态：</dt>
                    <dd><?php echo e(isset($status[$demand->status]) ? $status[$demand->status] : ''); ?></dd>
                    <div class="hr-line-dashed"></div>
                </dl>
            </div>
            <div class="col-sm-5" id="cluster_info">
                <dl class="dl-horizontal">

                    <dt>发布用户：</dt>
                    <dd><?php echo e(isset($demand->user->nickname) ? $demand->user->nickname : ''); ?></dd>
                    <div class="hr-line-dashed"></div>

                    <dt>代购用户：</dt>
                    <dd><?php echo e(isset($demand->selectUser->nickname) ? $demand->selectUser->nickname : ''); ?></dd>
                    <div class="hr-line-dashed"></div>

                    <dt>是否支付：</dt>
                    <dd><?php echo e($demand->is_pay?'是':'否'); ?></dd>
                    <div class="hr-line-dashed"></div>

                    <dt>支付时间：</dt>
                    <dd><?php echo e($demand->pay_time); ?></dd>
                    <div class="hr-line-dashed"></div>

                    <dt>发布时间：</dt>
                    <dd><?php echo e($demand->issue_time); ?></dd>
                    <div class="hr-line-dashed"></div>

                    <dt>结束时间：</dt>
                    <dd><?php echo e(date('Y-m-d H:i:s',$demand->end_time)); ?></dd>
                    <div class="hr-line-dashed"></div>

                    <dt>发货时间：</dt>
                    <dd><?php echo e($demand->delivery_time); ?></dd>
                    <div class="hr-line-dashed"></div>

                    <dt>收货人：</dt>
                    <dd><?php echo e($demand->consignee); ?>：<?php echo e($demand->phone); ?></dd>
                    <div class="hr-line-dashed"></div>

                    <dt>收货地址：</dt>
                    <dd><?php echo e($demand->address); ?></dd>
                    <div class="hr-line-dashed"></div>

                </dl>
            </div>
        </div>

        <div class="row m-t-sm">
            <div class="col-sm-12">
                <div class="panel blank-panel">

                    <div class="panel-body">
                        <div class="ibox-content">
                            <table class="table table-bordered">
                                <thead>
                                <tr>
                                    <th>商品名称</th>
                                    <?php /*<th>商品规格</th>*/ ?>
                                    <th>商品来源</th>
                                    <th>商品单价</th>
                                    <th>商品总价</th>
                                    <th>购买数量</th>
                                    <th>备注</th>
                                    <th>操作</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($demand->demandGoods as $v): ?>
                                    <tr>
                                        <td><?php echo e($v->name); ?></td>
                                        <?php /*<td><?php echo e($v->sku_name); ?></td>*/ ?>
                                        <td><?php echo e($v->source); ?></td>
                                        <td><?php echo e($v->known_unit_price); ?></td>
                                        <td><?php echo e($v->price); ?></td>
                                        <td><?php echo e($v->count); ?></td>
                                        <td><?php echo e($v->remark); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('admin/demand/goods-details/'.$v->id)); ?>" class="mod btn btn-primary">查看</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script charset="utf-8">

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>