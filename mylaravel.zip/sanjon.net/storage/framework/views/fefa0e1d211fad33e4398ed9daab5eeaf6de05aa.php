<?php $__env->startSection('title','优惠券'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/wechat/css/youhuiquan.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <ul class="Coupon clearfix">
        <li class="active"><a href="javascript:;">未使用</a></li>
        <li><a href="javascript:;">已使用</a></li>
        <li><a href="javascript:;">已过期</a></li>
    </ul>

    <div class="Couponcont">
        <ul class="active">
            <?php foreach($rows->filter(function($item){return $item->status==1 && strtotime($item->valid_time)>time();}) as $v): ?>
                <li class="">
                    <div class="couRed"></div>
                    <a href="javascript:;" class="clearfix">
                        <div class="fl couPrice">
                            <em>¥</em>
                            <span><?php echo e($v->price); ?></span>
                            <p>满<?php echo e($v->full_price_use); ?>使用</p>
                        </div>
                        <div class="fr couwords">
                            <p class="couwords1"><?php echo e($v->name); ?></p>
                            <div class="couwords2">有效期至<?php echo e($v->valid_time); ?></div>
                            <div class="couwords3"><?php echo e($v->description); ?><em></em></div>
                        </div>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>

        <ul>
            <?php foreach($rows->filter(function($item){return $item->status==2;}) as $v): ?>
                <li class="">
                    <div class="couRed"></div>
                    <a href="javascript:;" class="clearfix">
                        <div class="fl couPrice">
                            <em>¥</em>
                            <span><?php echo e($v->price); ?></span>
                            <p>满<?php echo e($v->full_price_use); ?>使用</p>
                        </div>
                        <div class="fr couwords">
                            <p class="couwords1"><?php echo e($v->name); ?></p>
                            <div class="couwords2">有效期至<?php echo e($v->valid_time); ?></div>
                            <div class="couwords3"><?php echo e($v->description); ?><em></em></div>
                        </div>
                    </a>
                    <div class="usedimg" title="已使用"></div>
                </li>
            <?php endforeach; ?>
        </ul>
        <ul>
            <?php foreach($rows->filter(function($item){return $item->status==1 && time()>strtotime($item->valid_time);}) as $v): ?>
                <li class="">
                    <div class="couRed"></div>
                    <a href="javascript:;" class="clearfix">
                        <div class="fl couPrice">
                            <em>¥</em>
                            <span><?php echo e($v->price); ?></span>
                            <p>满<?php echo e($v->full_price_use); ?>使用</p>
                        </div>
                        <div class="fr couwords">
                            <p class="couwords1"><?php echo e($v->name); ?></p>
                            <div class="couwords2">有效期至<?php echo e($v->valid_time); ?></div>
                            <div class="couwords3"><?php echo e($v->description); ?><em></em></div>
                        </div>
                    </a>
                    <div class="passedimg" title="已过期"></div>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        $(function () {
            //头部导航切换
            $('.Coupon li').click(function () {
                var i = $('.Coupon li').index($(this));
                $('.Coupon li').removeClass('active');
                $(this).addClass('active');
                $(".Couponcont ul").eq(i).addClass('active').siblings().removeClass("active");
            })
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>