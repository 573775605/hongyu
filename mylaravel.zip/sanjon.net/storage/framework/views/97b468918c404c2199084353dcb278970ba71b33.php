<?php $__env->startSection('title','个人中心'); ?>


<?php $__env->startSection('content'); ?>
    <div class="Mycenter" style="background:url(<?php echo e(asset('asset/wechat/img/26.png')); ?>) no-repeat;background-size:cover;">
        <div style="padding-top: 20px"></div>
        <p class="Mycenterimg">
            <img src="<?php echo e($user->img_url); ?>"/>
        </p>
        <p class="Mycentername"><?php echo e($user->nickname); ?></p>
        <?php /*<span class="Mycenternumber clearfix" onclick="location.href='<?php echo e(url('wechat/user/user-info')); ?>'"><?php echo e($user->mobile); ?>15484*/ ?>
        <span style="position: relative;display: inline-block;">
            <?php if($user->hide_mobile): ?>
                <span class="Mycenternumber clearfix" id="mobile"><?php echo e(str_replace(substr($user->mobile,3,4),'****',$user->mobile)); ?></span>
            <?php else: ?>
                <span class="Mycenternumber clearfix" id="mobile"><?php echo e($user->mobile); ?></span>
            <?php endif; ?>
            <em class="bianjiall" id="view" mobile="<?php echo e($user->hide_mobile?$user->mobile:str_replace(substr($user->mobile,3,4),'****',$user->mobile)); ?>"></em>
        </span>
        <a href="<?php echo e(url('wechat/user/user-info')); ?>" class="Mycenterbj" title="编辑"></a>
    </div>

    <ul class="mineicon">
        <li class="aboutUsicon11"><a href="<?php echo e(url('wechat/demand/index')); ?>" class="jiantou">红利需求订单</a></li>
        <li class="aboutUsicon12"><a href="<?php echo e(url('wechat/hotboom-demand/index')); ?>" class="jiantou">红利分享订单</a></li>
        <li class="aboutUsicon1"><a href="<?php echo e(url('wechat/center/tender-list')); ?>" class="jiantou">参加报价</a></li>
        <li class="aboutUsicon3"><a href="<?php echo e(url('wechat/user/wallet')); ?>" class="jiantou">我的钱包</a></li>
        <li class="aboutUsicon4 mt10"><a href="<?php echo e(url('wechat/hotboom-cart/index')); ?>" class="jiantou">我的代购车</a></li>
        <li class="aboutUsicon5"><a href="<?php echo e(url('wechat/address')); ?>" class="jiantou">收货地址</a></li>
        <li class="aboutUsicon6"><a href="<?php echo e(url('wechat/center/evaluate-grade')); ?>" class="jiantou">我的服务等级</a></li>
        <li class="aboutUsicon7 mt10"><a href="<?php echo e(url('wechat/about/index')); ?>" class="jiantou">关于我们</a></li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('asset/ext/layer/layer.min.js')); ?>"></script>
    <script>
        $(function () {
            $('#view').click(function () {
                var element=this;
                $.post("<?php echo e(url('wechat/user/hide-mobile')); ?>",
                    {_token: '<?php echo e(csrf_token()); ?>'},
                    function (data, status) {
                        if (data.status != 1) {
                            layer.msg('操作失败');
                        } else {
                            layer.msg('操作成功');
                            var txt = $('#mobile').text();
                            $('#mobile').text($(element).attr('mobile'));
                            $(element).attr('mobile', txt);
                        }
                    });
            });
        })
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>