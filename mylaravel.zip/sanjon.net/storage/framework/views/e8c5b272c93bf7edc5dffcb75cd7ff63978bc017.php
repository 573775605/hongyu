<?php if($type=='balance'): ?>
    <?php foreach($rows as $v): ?>
        <li>
            <p class="MlevelListword1"><?php echo e($v->create_time); ?></p>
            <div class="MlevelListword2">
                <?php if($v->demand_id): ?>
                    <dl class="MXdlall borderB clearfix">
                        <dt>订单号：</dt>
                        <dd><?php echo e($v->demand->order_number); ?></dd>
                    </dl>
                <?php endif; ?>
                <dl class="MXdlall clearfix">
                    <dt><?php echo e($v->remark); ?>：</dt>
                    <dd><span class="<?php echo e($v->change_balance>0?'Mlevelgreen':'Mlevelred'); ?>">¥<?php echo e($v->change_balance); ?></span></dd>
                </dl>
            </div>
        </li>
    <?php endforeach; ?>
<?php elseif($type=='pledge'): ?>
    <?php foreach($rows as $v): ?>
        <li>
            <p class="MlevelListword1"><?php echo e($v->create_time); ?></p>
            <div class="MlevelListword2">
                <?php if($v->demand_id): ?>
                    <dl class="MXdlall borderB clearfix">
                        <dt>订单号：</dt>
                        <dd><?php echo e($v->demand->order_number); ?></dd>
                    </dl>
                <?php endif; ?>
                <dl class="MXdlall clearfix">
                    <dt><?php echo e($v->remark); ?>：</dt>
                    <dd><span class="<?php echo e($v->change_pledge>0?'Mlevelgreen':'Mlevelred'); ?>">¥<?php echo e($v->change_pledge); ?></span></dd>
                </dl>
            </div>
        </li>
    <?php endforeach; ?>
<?php elseif($type=='hotboom-balance'): ?>
    <?php foreach($rows as $v): ?>
        <li>
            <p class="MlevelListword1"><?php echo e($v->create_time); ?></p>
            <div class="MlevelListword2">
                <?php if($v->demand_id): ?>
                    <dl class="MXdlall borderB clearfix">
                        <dt>订单号：</dt>
                        <dd><?php echo e($v->demand->order_number); ?></dd>
                    </dl>
                <?php endif; ?>
                <dl class="MXdlall clearfix">
                    <dt><?php echo e($v->remark); ?>：</dt>
                    <dd><span class="<?php echo e($v->change_balance>0?'Mlevelgreen':'Mlevelred'); ?>">¥<?php echo e($v->change_balance); ?></span></dd>
                </dl>
            </div>
        </li>
    <?php endforeach; ?>
<?php elseif($type=='spare'): ?>
    <?php foreach($rows as $v): ?>
        <li>
            <p class="MlevelListword1"><?php echo e($v->create_time); ?></p>
            <div class="MlevelListword2">
                <dl class="MXdlall borderB clearfix">
                    <dt>订单号：</dt>
                    <dd><?php echo e(isset($v->demand->order_number) ? $v->demand->order_number : ''); ?></dd>
                </dl>
                <dl class="MXdlall borderB clearfix">
                    <dt>已知订单总额：</dt>
                    <dd><span class="Mlevelred">¥<?php echo e(isset($v->demand->known_price) ? $v->demand->known_price : ''); ?></span></dd>
                </dl>
                <dl class="MXdlall borderB clearfix">
                    <dt>支付代购总额：</dt>
                    <dd><span class="Mlevelyellow">¥<?php echo e(isset($v->demand->price) ? $v->demand->price : ''); ?></span></dd>
                </dl>
                <dl class="MXdlall  clearfix">
                    <dt>节省金额：</dt>
                    <dd><span class="Mlevelgreen">¥<?php echo e($v->change_price); ?></span></dd>
                </dl>
            </div>
        </li>
    <?php endforeach; ?>
<?php endif; ?>