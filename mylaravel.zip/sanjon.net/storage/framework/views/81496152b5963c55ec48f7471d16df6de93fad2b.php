<?php $__env->startSection('title','需求详情'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/wechat/css/swiper-3.4.2.min.css')); ?>"/>
    <style>
        .swiper-container {
            width: 100%;
            height: 100%;
        }

        .swiper-slide {
            text-align: center;
            font-size: 18px;
            background: #fff;
            display: -webkit-box;
            display: -ms-flexbox;
            display: -webkit-flex;
            display: flex;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            -webkit-justify-content: center;
            justify-content: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            -webkit-align-items: center;
            align-items: center;
        }

        .XQbanner2 .swiper-pagination .swiper-pagination-bullet {
            width: 10px;
            height: 3px;
            background: rgba(0, 0, 0, 0.80) !important;
            border-radius: 13px;
        }

        .XQbanner2 .swiper-pagination .swiper-pagination-bullet-active {
            background: #F8525A !important;
            border-radius: 13px;
        }

        .XQbanner2 {
            overflow: hidden;
        }

        .XQbanner2 img {
            height: 100%;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="XQbanner2">
        <div class="swiper-container">
            <div class="swiper-wrapper">
                <?php foreach($goods->imgs as $v): ?>
                    <div class="swiper-slide"><img src="<?php echo e($v->url); ?>"/></div>
                <?php endforeach; ?>
            </div>
            <div class="swiper-pagination"></div>
        </div>
    </div>

    <div class="clearfix Uneedtime XQtime">
        <?php if($demand->isCirculation()): ?>
            <div class="UneedButtonlanse fl ">
                <input type="button" value="循环红利">
            </div>
        <?php else: ?>
            <?php if($demand->data->is_issue): ?>
                <div class="<?php echo e($demand->data->is_select?'UneedButtonhuise':'UneedButtonred'); ?> fl ">
                    <input type="button" value="<?php echo e($demand->data->is_select?'历史红利':'寻找红利'); ?>">
                </div>
            <?php else: ?>
                <div class="UneedButtonhuise fl ">
                    <input type="button" value="未发布">
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <?php /*循环红利，时间的背景色"timespanBlue"*/ ?>
        <?php if($demand->data->status==1||$demand->isCirculation()): ?>
            <div class="timespan fl <?php echo e($demand->isCirculation()?'timespanBlue':''); ?>" id="time1">
                <span class="day_show">0</span>&nbsp;<em>天</em>
                <span class="hour_show"><s id="h"></s>0</span>&nbsp;<em>时</em>
                <span class="minute_show"><s></s>0</span>&nbsp;<em>分</em>
                <span class="second_show"><s></s>0</span>&nbsp;<em>秒</em>
            </div>
        <?php endif; ?>
        <div class="Uneedtimejuli"><?php echo e($demand::countTimeInterval($demand->data->issue_time)); ?></div>
    </div>

    <div class="Uneedtit clearfix XQdingdan">
        <span class="Uword2">订单号:<?php echo e($demand->data->order_number); ?></span>
        <span class="Uorder">订单总额:<em class="Iprice">¥<?php echo e($demand->data->known_price); ?></em></span>
        <span class="btnsqueryellow fr" onclick="location.href='<?php echo e(url('wechat/about/explain-article/hotboom_assure_deal')); ?>'">担保交易</span>
    </div>

    <div class=" XQcont">
        <div class="XQcontwords">
            <div class="clearfix">
                <div class="fl orderLinkword">
                    <p class="Uneedcontwords1 ellipsis2"><?php echo e($goods->name); ?></p>
                </div>
                <?php if($goods->type=='link'): ?>
                    <?php if(in_array($goods->domain,['tmall','taobao'])): ?>
                        <a class="fr orderLinkgreen" href="<?php echo e(url('wechat/check-browse?url='.urlencode($goods->link))); ?>">
                            <input type="button" value="商品链接">
                        </a>
                    <?php else: ?>
                        <div class="fr orderLinkgreen" onclick="location.href='<?php echo e($goods->link); ?>'">
                            <input type="button" value="商品链接">
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class="clearfix">
                <div class="fl Uneedcontwords2"><em class="Uneedred1">¥<?php echo e($goods->known_unit_price); ?></em> / *<?php echo e($goods->count); ?><?php echo e($goods->unit); ?></div>
                <div class="fr Uneedcontwords3">货源： <em class="Uneedred1"><?php echo e($goods->source); ?></em></div>
            </div>
            <div class="beizu">备注：<?php echo e($goods->remark); ?></div>
        </div>
    </div>
    <?php if($demand->data->demandGoods->count()>1): ?>
        <p class="fabuing">本订单还包含以下商品</p>
        <?php foreach($demand->data->demandGoods as $v): ?>
            <?php if($v->id!=$goods->id): ?>
                <div class="clearfix XQgoods" onclick="location.href='<?php echo e(url('wechat/tender/demand-details/'.$demand->data->id.'?goods_id='.$v->id)); ?>'">
                    <div class="fl XQgoodsimg">
                        <img src="<?php echo e(isset($v->img->url) ? $v->img->url : ''); ?>"/>
                    </div>
                    <div class="fl XQgoodsCont">
                        <p class="ellipsis1 XQgoodsword2"><?php echo e($v->name); ?></p>
                        <p class="ellipsis1">
                            <span class="XQgoodsword1">¥<em class="Uneedred1"><?php echo e($v->known_unit_price); ?></em>/ *<?php echo e($v->count); ?><?php echo e($v->unit); ?></span>
                            <?php /*<span class="XQgoodsword1">商品合计：¥<em class="XQgoodsword1red"><?php echo e($v->price); ?></em></span>*/ ?>
                        </p>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>
    <?php endif; ?>
    <?php if($goods->getSite()): ?>
        <div class="XQadress jiantou" onclick="location.href='<?php echo e(url('wechat/tender/store-site/'.$goods->id)); ?>'">
            <p class="mapwrodd">需求实体店位置</p>
            <p class="XQadressicon ellipsis1"><?php echo e($goods->getSite()); ?></p>
            <p class="XQadresword1">距您：<?php echo e($distance); ?>km</p>
        </div>
    <?php endif; ?>
    <?php if(isset($tender)): ?>
        <p class="fabuing">报价信息</p>
        <div class="XQTotal clearfix " style="margin-top: 0;">
            <div class="noyoufei">
                  <span class="XQTotalwrod1">
                报价总额：<em class="XQTotalred1">￥</em>
                <em class="XQTotalred2"><?php echo e($tender->getPrice()); ?></em>
            </span>
                <span class="XQTotalwrod3">
                邮费：<em class="XQTotalred1">￥</em>
                    <em class="XQTotalred2"><?php echo e($tender->express_price); ?></em>
            </span>
                <span class="XQTotalwrod2 ">
                较已知订单总额节省（不含邮费）<em class="XQTotalgreen1">￥</em>
                <em class="XQTotalgreen2">
                    <?php echo e($demand->data->known_price-$tender->getPrice()<0?0:$demand->data->known_price-$tender->getPrice()); ?>

                </em>
            </span>
            </div>
            <?php if($demand->isCirculation()): ?>
                <div class="peoplenumber clearfix">
                    <p class="XQmassegeword3 peoplenumber1">红利库存：<em class="green"><?php echo e($demand->getHotboomRepertory()); ?></em></p>
                    <p class="XQmassegeword3 peoplenumber2">累计<em class="green"><?php echo e($demand->getCirculationCount()); ?></em>人跟随</p>
                </div>
            <?php endif; ?>
        </div>
        <p class="fabuing">报价优势
            <span class="fabuingtips">(请注意报价货源，平台不允许代购无法溯源商家的产品)</span>
        </p>
        <ul class="XQadvantage clearfix">
            <?php if($tender->type=='other-hotboom'): ?>
                <li class="qustion" onclick="location.href='<?php echo e(url('wechat/demand/hotboom-store-site?lng='.$tender->hotboom_lng.'&lat='.$tender->hotboom_lat.'&name='.$tender->hotboom_store_name)); ?>'">
                    其他商家
                </li>
            <?php else: ?>
                <li>原路代购</li>
            <?php endif; ?>
            <?php foreach($tender->quoteAdvantage as $v): ?>
                <?php foreach(json_decode($v->label,true) as $v1): ?>
                    <li><?php echo e($v1); ?></li>
                <?php endforeach; ?>
                <?php if($v->other): ?>
                    <li><?php echo e($v->other); ?></li>
                <?php endif; ?>
            <?php endforeach; ?>
        </ul>

        <?php if($demand->data->is_select): ?>
            <div class="XQmassegeall">
                <div class="jiantou jiantoubs" onclick="location.href='<?php echo e(url('wechat/user/hotboom-info/'.$tender->id)); ?>'">

                    <div class="clearfix ">
                        <p style="    font-size: 10px; color: #333;">报价人</p>

                        <div class="fl clearfix XQmassegeR">
                            <div class="XQmassegeimg fl">
                                <img src="<?php echo e(isset($demand->data->selectUser->img_url) ? $demand->data->selectUser->img_url : ''); ?>">
                            </div>
                            <div class="fl XQmassegewordR" style="width: 63%;">
                                <div>
                            <span class="XQmassegeword1">
                                <em class="ellipsis1"><?php echo e(isset($demand->data->selectUser->nickname) ? $demand->data->selectUser->nickname : ''); ?></em>
                            </span>
                                    <em class="XQmassegeicon1<?php echo e($demand->data->selectUser->mobile?'':'NO'); ?>"></em>
                                    <em class="XQmassegeicon2<?php echo e($demand->data->selectUser->is_auth?'':'NO'); ?>"></em>
                                </div>
                                <?php if($demand->data->selectUser->hide_mobile): ?>
                                    <p class="XQmassegeword2"><?php echo e(str_replace(substr($demand->data->selectUser->mobile,3,4),'****',$demand->data->selectUser->mobile)); ?></p>
                                <?php else: ?>
                                    <p class="XQmassegeword2"><?php echo e($demand->data->selectUser->mobile); ?></p>
                                <?php endif; ?>
                                <p class="XQmassegeword3">成交笔数：<em class="green"><?php echo e(isset($demand->data->selectUser->daigou_over_demand) ? $demand->data->selectUser->daigou_over_demand : ''); ?></em></p>
                            </div>
                        </div>

                        <div class="fr XQmassegeL  clearfix">
                            <div class="clearfix">

                                <em class="fr XQmassegestart Aisstart<?php echo e(isset($demand->data->selectUser->evaluate_avg_grade) ? $demand->data->selectUser->evaluate_avg_grade : 0); ?>"></em>
                                <span class="XQhlword">红利分享信誉</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix chatselect">
                    <?php if($demand->data->is_select): ?>
                        <span class="fr sButtongrey "><input type="button" value="已选择"/></span>
                    <?php endif; ?>
                    <span class="fr sButtongyellow mr10" onclick="location.href='<?php echo e(url('wechat/chat/message/'.$demand->data->selectUser->id)); ?>'">
                            <input type="button" value="聊天"/></span>
                </div>
            </div>
        <?php endif; ?>

        <?php /*<div class="XQTotal clearfix " style="margin-top: 0;">*/ ?>
        <?php /*<div class="noyoufei">*/ ?>
        <?php /*<span class="XQTotalwrod1">*/ ?>
        <?php /*报价总额：<em class="XQTotalred1">￥</em>*/ ?>
        <?php /*<em class="XQTotalred2"><?php echo e($tender->getPrice()); ?></em>*/ ?>
        <?php /*</span>*/ ?>
        <?php /*<span class="XQTotalwrod3">*/ ?>
        <?php /*邮费：<em class="XQTotalred1">￥</em>*/ ?>
        <?php /*<em class="XQTotalred2"><?php echo e($tender->express_price); ?></em>*/ ?>
        <?php /*</span>*/ ?>
        <?php /*<span class="XQTotalwrod2 ">*/ ?>
        <?php /*较已知订单总额节省（不含邮费）<em class="XQTotalgreen1">￥</em>*/ ?>
        <?php /*<em class="XQTotalgreen2">*/ ?>
        <?php /*<?php echo e($demand->data->known_price-$tender->getPrice()<0?0:$demand->data->known_price-$tender->getPrice()); ?>*/ ?>
        <?php /*</em>*/ ?>
        <?php /*</span>*/ ?>
        <?php /*</div>*/ ?>
        <?php /*<?php if($demand->isCirculation()): ?>*/ ?>
        <?php /*<div class="peoplenumber clearfix">*/ ?>
        <?php /*<p class="XQmassegeword3 peoplenumber1">红利库存：<em class="green"><?php echo e($demand->getHotboomRepertory()); ?></em></p>*/ ?>
        <?php /*<p class="XQmassegeword3 peoplenumber2">累计<?php echo e($demand->getCirculationCount()); ?>人跟随</p>*/ ?>
        <?php /*</div>*/ ?>
        <?php /*<?php endif; ?>*/ ?>
        <?php /*</div>*/ ?>

        <?php if(!request('tender_id')): ?>
            <div class="clearfix evaluateall">
                <div class="fl evaluate">
                    收到的评价(<?php echo e($evaluateCount); ?>)
                </div>
                <a class="fr evaluateMore" href="<?php echo e(url('wechat/user/all-evaluate/hotboom/'.$tender->user_id)); ?>">
                    更多评价
                </a>
            </div>
            <ul class="evaluateUl ">
                <?php foreach($evaluate as $v): ?>
                    <li class="clearfix">
                        <div class="evaluateUlimg">
                            <img src="<?php echo e(isset($v->evaluateUser->img_url) ? $v->evaluateUser->img_url : ''); ?>"/>
                        </div>
                        <div class="evaluateUlR">
                            <div class="clearfix evaluateUltit">
                                <div class="fl evaluateUltit1">
                                    <span class="ellipsis1"><?php echo e(isset($v->evaluateUser->nickname) ? $v->evaluateUser->nickname : ''); ?></span>
                                </div>
                                <div class="fr evaluateUltit2">
                                    <span class="ellipsis1"><?php echo e($v->create_time); ?></span>
                                </div>
                            </div>
                            <div class="evaluateUltit3 ellipsis1">
                                <?php echo e($v->content); ?>

                            </div>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>

    <?php endif; ?>
    <div class="XQmassegeall ">
        <a class="  XQa " style="" href="<?php echo e(url('wechat/user/issue-demand/'.$demand->data->user_id.'/'.$demand->data->id)); ?>">
            <div class="jiantou jiantoubs">
                <div class="clearfix">
                    <p class="faqiren">需求发起人</p>
                    <div class="fl clearfix XQmassegeR">
                        <div class="XQmassegeimg fl"><img src="<?php echo e(isset($demand->data->user->img_url) ? $demand->data->user->img_url : ''); ?>"></div>
                        <div class="fl XQmassegewordR">
                            <div><span class="XQmassegeword1"><em class="ellipsis1"><?php echo e(isset($demand->data->user->nickname) ? $demand->data->user->nickname : ''); ?></em></span></div>
                            <p class="Userword2">成交量：<em class="green"><?php echo e($demand->data->user->issue_over_demand?:0); ?></em></p>
                            <p class="XQmassegeword3"><?php echo e($demand::countTimeInterval($demand->data->user->update_time).'来过'); ?></p></div>
                    </div>

                    <div class="fr XQmassegeL clearfix " style="    margin-top: 4px;">
                        <div class="clearfix">
                            <em class="fr XQmassegestart Aisstart<?php echo e(isset($demand->data->user->daigou_evaluate_avg_grade) ? $demand->data->user->daigou_evaluate_avg_grade : '0'); ?>"></em>
                            <span class="XQhlword">红利需求信誉</span>
                        </div>
                    </div>
                </div>
            </div>
        </a>

        <div class="clearfix chatselect2 ">
        <span class="fl sButtongyellow mr10" onclick="location.href='<?php echo e(url('wechat/chat/message/'.$demand->data->user_id)); ?>'">
                            <input type="button" value="聊天"/></span>
        </div>
    </div>
    <div class="baoadressall clearfix">
        <p class="baophone fl"><?php echo e(str_replace(substr($demand->data->phone,3,4),'****',$demand->data->phone)); ?></p>
        <div class="baoadress fr">
            <p class=" XQadressicon ellipsis1 "><?php echo e($demand->hideAddress()); ?></p>
        </div>
    </div>
    <div class="baolook">*订单收件人地址电话信息，报价被选中后才能查看</div>

    <div style="height: 45px;"></div>

    <?php if(request('tender_id')): ?>
        <?php if($tender->status==1): ?>
            <a class="Lbtnred" href="<?php echo e(url('wechat/tender/edit/'.request('tender_id'))); ?>">
                修改报价
            </a>
        <?php else: ?>
            <?php if($tender->hotboom_type=='circulation'&&!$tender->isDelete()): ?>
                <a class="Lbtnred" href="<?php echo e(url('wechat/tender/edit-repertory/'.request('tender_id'))); ?>">
                    修改库存
                </a>
            <?php endif; ?>
        <?php endif; ?>

    <?php else: ?>
        <?php if($demand->data->status==1&&$demand->data->userTender->count()<$tenderMaxCount): ?>
            <div class="XQbottom clearfix">
                <a class="XQbottomchat" href="<?php echo e(url('wechat/chat/message/'.$demand->data->user_id)); ?>">聊天</a>
                <a class="XQbottomenter" href="javascript:addCart(<?php echo e($demand->data->id); ?>)"><input type="button" value="加入代购车"/></a>
                <a class="XQbottomBJ" href="javascript:tenderCheck(<?php echo e($demand->data->id); ?>)">马上报价</a>
            </div>
        <?php endif; ?>
        <?php if($demand->isCirculation()&&$user->data->id!=$demand->data->select_user_id&&$demand->data->is_select): ?>
            <a class="Lbtnblue" href="<?php echo e(url('wechat/demand/copy-demand/'.$demand->data->id)); ?>">
                我要跟单
            </a>
        <?php endif; ?>
    <?php endif; ?>
    <div class="bg"></div>
    <div class="tan">
        <div class="tanclose">+</div>
        <div class="tanimg3" title="图片"></div>
        <p class="tanimgword1">发布需求前，需要认证个人信息!</p>
        <a class="redbtn90 tanbtnclose">
            <input type="button" value="去认证" onclick="location.href='<?php echo e(url('wechat/user/bind-mobile?demand_id='.$demand->data->id)); ?>'"/>
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('asset/wechat/js/swiper-3.4.2.min.js')); ?>" type="text/javascript" charset="utf-8"></script>
    <script src="<?php echo e(asset('asset/ext/layer/layer.min.js')); ?>"></script>
    <script>
        //投标验证
        function tenderCheck(id) {
            $.post("<?php echo e(url('wechat/tender/tender-check')); ?>/" + id,
                {_token: '<?php echo e(csrf_token()); ?>'},
                function (data, status) {
                    if (data.status != 1) {
                        if (data.status == -1) {
                            $(".tan,.bg").show();
                        } else {
                            layer.msg(data.message);
                        }
                    } else {
                        location.href = '<?php echo e(url('wechat/tender/index?demand_id=')); ?>' + id;
                    }
                });
        }

        //添加代购车
        function addCart(id) {
            $.post("<?php echo e(url('wechat/hotboom-cart/add')); ?>/" + id,
                {_token: '<?php echo e(csrf_token()); ?>'},
                function (data, status) {
                    if (data.status != 1) {
                        layer.msg(data.message);
                    } else {
                        layer.msg('添加成功');
                    }
                });
        }

        //banner高度
        var bannerH = $(".XQbanner2").width();
        $(".XQbanner2").css("height", bannerH);

        $(".tanclose,.bg,.tanbtnclose").click(function () {
            $(".tan,.bg").hide();
        })

        var swiper = new Swiper('.swiper-container', {//banner
            pagination: '.swiper-pagination',
            paginationClickable: true,
        });

        /***********************************倒计时 开始**************************************************************/
        $(function () {
            <?php if($demand->isCirculation()): ?>
            timer(parseInt(<?php echo e($demand->data->selectUserTender->hotboom_end_time-time()); ?>), "#time1");
            <?php else: ?>
            timer(parseInt(<?php echo e($demand->data->end_time-time()); ?>), "#time1");
            <?php endif; ?>
        })
        function timer(intDiff, obj) {//倒计时
            window.setInterval(function () {
                var day = 0,
                    hour = 0,
                    minute = 0,
                    second = 0;//时间默认值
                if (intDiff > 0) {
                    day = Math.floor(intDiff / (60 * 60 * 24));
                    hour = Math.floor(intDiff / (60 * 60)) - (day * 24);
                    minute = Math.floor(intDiff / 60) - (day * 24 * 60) - (hour * 60);
                    second = Math.floor(intDiff) - (day * 24 * 60 * 60) - (hour * 60 * 60) - (minute * 60);
                }
                if (minute <= 9) minute = '0' + minute;
                if (second <= 9) second = '0' + second;
                $(obj + ' .day_show').html(day);
                $(obj + ' .hour_show').html('<s id="h"></s>' + hour);
                $(obj + ' .minute_show').html('<s></s>' + minute);
                $(obj + ' .second_show').html('<s></s>' + second);
                intDiff--;
            }, 1000);
        }
    </script>
    <script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js" charset="utf-8"></script>
    <script>
        //微信分享配置
        wx.config(<?php echo $js->config(['onMenuShareTimeline','onMenuShareAppMessage'],false); ?>);
        wx.ready(function () {
            //分享朋友圈
            wx.onMenuShareTimeline({
                <?php if($demand->data->is_select): ?>
                title: '共享钱包，您挑商品我下单，立省¥<?php echo e($demand->getSaveprice()); ?>，上【红鱼】公众号体验购物新玩法！',
                                title: '(节省金额￥<?php echo e($demand->getSaveprice()); ?>)我在【红鱼】找到了能更低价拿货的牛人，快来围观吧', // 分享标题
                        <?php else: ?>
                title: '(已知售价￥<?php echo e($goods->known_unit_price); ?>)我在【红鱼】等待能更低价拿货的牛人，是你吗？', // 分享标题
                <?php endif; ?>
                link: '', // 分享链接
                imgUrl: '<?php echo e(isset($goods->img->url) ? $goods->img->url : ''); ?>', // 分享图标
                success: function () {
                    // 用户确认分享后执行的回调函数
                },
                cancel: function () {
                    // 用户取消分享后执行的回调函数
                }
            });
            //分享微信好友
            wx.onMenuShareAppMessage({
                <?php if($demand->data->is_select): ?>
                title: '共享钱包，您挑商品我下单，立省¥<?php echo e($demand->getSaveprice()); ?>，上【红鱼】公众号体验购物新玩法！',
                                title: '(节省金额￥<?php echo e($demand->getSaveprice()); ?>)我在【红鱼】找到了能更低价拿货的牛人，快来围观吧', // 分享标题
                desc: '<?php echo e($goods->name); ?>', // 分享描述
                <?php else: ?>
                title: '(已知售价￥<?php echo e($goods->known_unit_price); ?>)我在【红鱼】等待能更低价拿货的牛人，是你吗？', // 分享标题
                desc: '<?php echo e($goods->name); ?>', // 分享描述
                <?php endif; ?>
                link: '', // 分享链接
                imgUrl: '<?php echo e(isset($goods->img->url) ? $goods->img->url : ''); ?>', // 分享图标
                type: '', // 分享类型,music、video或link，不填默认为link
                dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                success: function () {
                    // 用户确认分享后执行的回调函数
                },
                cancel: function () {
                    // 用户取消分享后执行的回调函数
                }
            });
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>