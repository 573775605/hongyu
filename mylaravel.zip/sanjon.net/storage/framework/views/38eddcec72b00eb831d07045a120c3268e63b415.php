<?php $__env->startSection('title','我的评分等级'); ?>

<?php $__env->startSection('content'); ?>
    <div id="testel">
        <a href="<?php echo e(url('wechat/center/evaluate-grade-log?type=issue')); ?>" class="disb jiantou  ">
            <dl class="OrderLogistics3 clearfix">
                <dt>红利需求等级：</dt>
                <dd>
                    <div class="Bstart<?php echo e($user->daigou_evaluate_avg_grade); ?>">

                    </div>
                </dd>
            </dl>
        </a>

        <a href="<?php echo e(url('wechat/center/evaluate-grade-log?type=hotboom')); ?>" class="disb jiantou  ">
            <dl class="OrderLogistics3 clearfix">
                <dt>红利分享等级：</dt>
                <dd>
                    <div class="Bstart<?php echo e($user->evaluate_avg_grade); ?>">

                    </div>
                </dd>
            </dl>
        </a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>