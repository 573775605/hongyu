<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>小红鱼 - <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="_token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <?php $__env->startSection('mui-css'); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/wechat/css/mui.min.css')); ?>"/>
    <?php echo $__env->yieldSection(); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/wechat/css/index.css')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/wechat/css/public.css')); ?>"/>
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body class="<?php echo $__env->yieldContent('body'); ?>">
<?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<script src="<?php echo e(asset('asset/wechat/js/jquery.min.js')); ?>" type="text/javascript" charset="utf-8"></script>
<?php $__env->startSection('mui-js'); ?>
    <script src="<?php echo e(asset('asset/wechat/js/mui.min.js')); ?>" type="text/javascript" charset="utf-8"></script>
<?php echo $__env->yieldSection(); ?>
<script>
    var flag = false;
    function checkForm() {
        if (flag === true) {
            return false;
        }
        flag = true;
        return true;
    }
</script>
<?php echo $__env->yieldContent('js'); ?>