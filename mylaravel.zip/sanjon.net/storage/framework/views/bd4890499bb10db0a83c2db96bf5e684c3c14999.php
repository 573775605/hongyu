<?php foreach($rows as $v): ?>
<li class="clearfix">
    <div class="evaluateUlimg">
        <img src="<?php echo e(isset($v->evaluateUser->img_url) ? $v->evaluateUser->img_url : ''); ?>"/>
    </div>
    <div class="evaluateUlR">
        <div class="clearfix evaluateUltit">
            <div class="fl evaluateUltit1">
                <span class="ellipsis1"><?php echo e(isset($v->evaluateUser->nickname) ? $v->evaluateUser->nickname : ''); ?></span>
            </div>
            <div class="fr evaluateUltit2">
                <span class="ellipsis1"><?php echo e($v->create_time); ?></span>
            </div>
        </div>
        <div class="evaluateUltit3 ellipsis1">
            <?php echo e($v->content); ?>

        </div>
    </div>
</li>
<?php endforeach; ?>