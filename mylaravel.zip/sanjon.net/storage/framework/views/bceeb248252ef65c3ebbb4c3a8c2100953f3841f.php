<?php $__env->startSection('title','银行卡列表'); ?>

<?php $__env->startSection('content'); ?>
    <div style="height:10px;"></div>
    <div class="bgfff">
        <?php foreach($rows as $v): ?>
            <div class="addcarall">
                <dl class="addcar clearfix">
                    <dt class="clearfix">
                    <div class="fl">姓名：</div>
                    <div class="fl" style="width: 80%;">
                        <span class="ellipsis1 addcarword1"><?php echo e($v->name); ?></span>
                    </div>
                    </dt>
                    <dd>银行：<span class="addcarword1"><?php echo e($v->bank_name); ?></span></dd>
                </dl>
                <dl class="addcar clearfix">
                    <dt class="clearfix">
                    <div class="fl">
                        卡号：
                    </div>
                    <div class="fl">
                        <span class="ellipsis1 addcarword1"><?php echo e($v->account); ?></span>
                    </div>
                    </dt>
                    <dd onclick="removeNumber(<?php echo e($v->id); ?>)"><em class="delcar">删除</em></dd>
                </dl>
            </div>
        <?php endforeach; ?>
    </div>
    <a class="redbtn90" href="<?php echo e(url('wechat/wallet/add-bank')); ?>">
        <input type="button" value="添加"/>
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        function removeNumber(id) {
            if (confirm('确定要删除此银行卡')) {
                $.post("<?php echo e(url('wechat/wallet/remove-bank')); ?>/" + id,
                    {_token: '<?php echo e(csrf_token()); ?>'},
                    function (data, status) {
                        if (data.status != 1) {
                            alert(data.message);
                        } else {
                            location.reload();
                        }
                    });
            }
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>