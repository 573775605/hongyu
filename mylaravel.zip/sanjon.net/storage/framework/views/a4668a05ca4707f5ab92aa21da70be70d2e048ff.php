<?php $__env->startSection('title','介绍说明'); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('asset/admin/js/plugins/summernote/summernote.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <?php echo $__env->make('admin.layout.hint', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <form class="form-horizontal" id="base_form" method="post">
                <?php echo csrf_field(); ?>

                <div class="ibox float-e-margins">
                    <?php foreach($explain as $v): ?>
                    <div class="ibox-title">
                        <h5><?php echo e($v->title); ?></h5>
                    </div>
                    <div class="ibox-content">
                        <textarea name="<?php echo e($v->key); ?>" class="summernote"><?php echo $v->value; ?></textarea>
                    </div>
                    <?php endforeach; ?>

                    <div class="form-group">
                        <div class="col-sm-4 col-sm-offset-5">
                            <button class="btn btn-primary">保存内容</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php /*富文本编辑器*/ ?>
    <script src="<?php echo e(asset('asset/admin/js/plugins/summernote/summernote.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/admin/js/plugins/summernote/summernote-zh-CN.js')); ?>"></script>
    <?php /*上传插件*/ ?>
    <script src="<?php echo e(asset("asset/admin/js/plugins/jquery_file_upload/vendor/jquery.ui.widget.js")); ?>"></script>
    <script src="<?php echo e(asset("asset/admin/js/plugins/jquery_file_upload/jquery.iframe-transport.js")); ?>"></script>
    <script src="<?php echo e(asset("asset/admin/js/plugins/jquery_file_upload/jquery.fileupload.js")); ?>"></script>
    <script>
        $(document).ready(function () {
            $('.summernote').summernote({
                lang: 'zh-CN',
                height: '300px',
                callbacks: {
                    onImageUpload: function (files) {
                        var element = this;
                        var formData = new FormData();
                        formData.append('file', files[0]);
                        formData.append('_token', '<?php echo e(csrf_token()); ?>');
                        $.ajax({
                            url: '<?php echo e(url('admin/upload')); ?>',//后台文件上传接口
                            type: 'POST',
                            data: formData,
                            processData: false,
                            contentType: false,
                            success: function (data) {
                                $(element).summernote('insertImage', data.data.url, 'img');
                            }
                        });
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin/layout/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>