<?php $__env->startSection('title','退货申请'); ?>

<?php $__env->startSection('content'); ?>
    <form action="" method="post" onsubmit="return submitCheck()">
        <?php echo csrf_field(); ?>

        <input type="hidden" name="type" value="<?php echo e(request('type')); ?>">
        <dl class="offers clearfix">
            <dt class="mt5">申请原因：</dt>
            <dd>
                <div class="OrderLotextarea">
                    <textarea placeholder="请输入申请原因" name="remark"></textarea>
                </div>
            </dd>
        </dl>
        <?php if(request('type')=='return-money'): ?>
            <dl class="offers clearfix">
                <dt>退款金额：</dt>
                <dd>
                    <span class="wred">¥<?php echo e($demand->price); ?></span>
                </dd>
            </dl>
        <?php endif; ?>
        <a class="redbtn90">
            <input type="submit" value="确认"/>
        </a>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('asset/ext/layer/layer.min.js')); ?>"></script>
    <script>
        function submitCheck() {
            if ($('textarea[name=remark]').val() == '') {
                layer.msg('请填写申请原因');
                return false;
            }
            return true;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wechat.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>